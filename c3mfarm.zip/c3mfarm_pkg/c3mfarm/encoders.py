"""
Stage 1 -- modality-specific encoding (Eq. 1-2).

    X_i(t) = { X_i^s(t), X_i^v(t), X_i^a(t), X_i^l(t), X_i^w(t) }        (1)
    h_i^m  = E_m( X_i^m(t) ),  m in {s, v, a, l, w}                      (2)

Each encoder consumes a modality-specific input window and produces a
fixed-size representation h_i^m in R^{d_h}. Sensor / spectral / acoustic
views are treated as (batch, window_length, channels) sequences and
encoded with a GRU. The text/log view is treated as a token-id sequence
and encoded with an embedding + GRU. The weather/context view is a
low-dimensional static vector (operating settings) encoded with an MLP.
"""
from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn

from .config import C3MFarmConfig


class SequenceEncoder(nn.Module):
    """GRU-based encoder for time-series-like modalities (sensor / spectral / acoustic)."""

    def __init__(self, in_channels: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.gru = nn.GRU(
            input_size=in_channels,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            dropout=dropout if dropout > 0 else 0.0,
            bidirectional=False,
        )
        self.norm = nn.LayerNorm(hidden_dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, L, C)
        out, h_n = self.gru(x)
        h = h_n[-1]  # last layer's final hidden state, (B, hidden_dim)
        return self.drop(self.norm(h))


class TextEncoder(nn.Module):
    """Embedding + GRU encoder for the maintenance-log / synthetic-text view."""

    def __init__(self, vocab_size: int, hidden_dim: int, dropout: float, embed_dim: int = 64):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.gru = nn.GRU(embed_dim, hidden_dim, num_layers=1, batch_first=True)
        self.norm = nn.LayerNorm(hidden_dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        # tokens: (B, T) integer ids
        emb = self.embed(tokens)
        out, h_n = self.gru(emb)
        return self.drop(self.norm(h_n[-1]))


class ContextEncoder(nn.Module):
    """MLP encoder for static, low-dimensional weather/context (operating-setting) vectors."""

    def __init__(self, in_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, in_dim)
        return self.net(x)


def build_encoders(config: C3MFarmConfig) -> nn.ModuleDict:
    """Factory that builds E_s, E_v, E_a, E_l, E_w per the active modalities.

    "l" (text) is treated specially: its raw input is a token-id sequence,
    so `input_dims["l"]` is interpreted as the vocabulary size for that
    modality rather than a channel count.
    """
    encoders: Dict[str, nn.Module] = {}
    for m in config.active_modalities:
        dim = config.input_dims.get(m, 0)
        if dim <= 0:
            continue
        if m == "l":
            encoders[m] = TextEncoder(vocab_size=dim, hidden_dim=config.encoder_hidden_dim, dropout=config.dropout)
        elif m == "w":
            encoders[m] = ContextEncoder(in_dim=dim, hidden_dim=config.encoder_hidden_dim, dropout=config.dropout)
        else:  # "s", "v", "a" -- sequence-like modalities
            encoders[m] = SequenceEncoder(in_channels=dim, hidden_dim=config.encoder_hidden_dim, dropout=config.dropout)
    return nn.ModuleDict(encoders)
