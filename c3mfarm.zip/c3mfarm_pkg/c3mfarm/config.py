"""
Configuration for C3M-Farm.

All defaults reproduce Table 2 of the paper:
"Causal-Inspired Cross-Asset Contrastive Multimodal Maintenance Network:
A Proxy-Benchmark Study for Renewable-Energy Maintenance" (C3M-Farm).

Values marked "reported experiment" come directly from the paper's Table 2.
Anything the paper explicitly flags as *not preserved* in the archived
record (window stride, random seeds, exact STFT parameters, synthetic-text
generation rule, proxy-graph construction details, hardware) is exposed
here as an explicit, documented default rather than silently assumed --
see the docstrings below and README "Reproducibility gaps" section.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


MODALITIES = ("s", "v", "a", "l", "w")  # sensor, visual/spectral, acoustic, log/text, weather/context


@dataclass
class C3MFarmConfig:
    # ---- Table 1 notation carried through as dimensions -------------------
    modalities: Tuple[str, ...] = MODALITIES

    # Per-modality *raw input* feature dimension. For the C-MAPSS proxy
    # benchmark only "s" (sensor) and "w" (operating settings -> weather/
    # context) are measured directly; "v" (STFT spectral), "a" (unused /
    # optional acoustic-analogue) and "l" (synthetic text) are derived
    # proxy views. Set a modality's dim to 0 (or omit it from
    # `active_modalities`) to disable it.
    input_dims: Dict[str, int] = field(default_factory=lambda: {
        "s": 14,   # C-MAPSS: 21 sensors, commonly 14 informative channels after pruning
        "v": 64,   # STFT magnitude bins (derived proxy view, see data.py)
        "a": 0,    # not measured in C-MAPSS; disabled by default
        "l": 32,   # synthetic-text token/bag-of-symbol vector (proxy view, see data.py)
        "w": 3,    # operating settings (op_setting_1..3) used as context
    })

    # Which modalities are actually active for a given run.
    active_modalities: Tuple[str, ...] = ("s", "v", "l", "w")

    # ---- Table 2: architecture hyperparameters -----------------------------
    window_length: int = 128            # L, reported experiment
    encoder_hidden_dim: int = 128        # d_h
    unified_latent_dim: int = 256        # D_u  (per-subspace dim; health/env/residual each = D_u // 3 by default)
    graph_hidden_dim: int = 128          # d_g
    num_graph_layers: int = 2            # L_g (paper reports "2 or 3"; default to 2)
    dropout: float = 0.3                 # p

    # ---- Table 2: optimization hyperparameters -----------------------------
    batch_size: int = 32                 # B
    learning_rate: float = 1e-4          # eta
    weight_decay: float = 1e-5
    contrastive_temperature: float = 0.07  # tau
    num_epochs: int = 100
    early_stopping_patience: int = 10    # not specified numerically in the paper; documented default

    # ---- Table 2: loss weights (Eq. 24) -------------------------------------
    lambda_cmc: float = 1.0     # lambda_1
    lambda_orth: float = 0.1    # lambda_2
    lambda_rec: float = 0.5     # lambda_3
    lambda_cls: float = 1.0     # lambda_4
    lambda_rul: float = 1.0     # lambda_5
    lambda_risk: float = 0.0    # lambda_6 -- inactive in the reported experiment (no risk labels/horizon)
    lambda_traj: float = 0.5    # lambda_7

    # ---- Task configuration -------------------------------------------------
    num_classes: int = 2          # binary healthy/faulty by default; set per dataset
    use_risk_head: bool = False   # architectural extension only; keep False unless you supply Y_risk
    trajectory_horizon: int = 1   # Delta, in windows, for L_traj (Eq. 23)

    # ---- Graph construction (Eq. 10) ----------------------------------------
    # The paper is explicit that the *empirical* proxy-graph construction
    # (edge variables, similarity function, k/threshold, normalization,
    # update schedule, train-only-ness) was not preserved in the archived
    # record and must be published for any reproducible rerun. The values
    # below are therefore a documented, conservative default -- a k-NN
    # graph over operating-condition similarity (CondSim) only -- and are
    # NOT a claim about the original experiment's exact graph.
    alpha_geo: float = 0.0     # alpha_1 -- no geographic info available in C-MAPSS -> 0
    alpha_cond: float = 1.0    # alpha_2 -- operating-condition similarity, the only physically meaningful proxy signal
    alpha_elec: float = 0.0    # alpha_3 -- no electrical topology available in C-MAPSS -> 0
    graph_knn_k: int = 8       # k for k-NN sparsification of A_ij
    graph_self_loops: bool = True  # A~ = A + I (Eq. 11)

    # ---- Reproducibility bookkeeping ----------------------------------------
    # A place to record whatever you actually used, so future re-runs of
    # *your* experiment (unlike the archived one) remain auditable.
    random_seed: int = 42
    notes: str = (
        "Window stride, exact STFT parameters, synthetic-text generation "
        "rule, and proxy-graph construction are not specified in the "
        "source paper's archived record. Defaults chosen here are "
        "documented in config.py / data.py and must be reported "
        "explicitly in any results derived from this implementation."
    )

    @property
    def subspace_dim(self) -> int:
        """Dimension of each of the health / environment / residual subspaces."""
        d = self.unified_latent_dim // 3
        return max(d, 1)

    @property
    def fused_dim(self) -> int:
        """Dimension of the fused per-asset embedding u_i (Eq. 13/15)."""
        return self.subspace_dim  # health, env, residual, graph reps all live in subspace_dim and are attention-pooled to subspace_dim
