"""
Training procedure (Algorithm 1, Sec. 3.3):

    Input: D = {Xs, Xv, Xa, Xl, Xw}, G = (V, E, A), Ycls, Yrul (Yrisk optional),
           lambda_1..7, tau, eta
    Output: trained parameters theta

    1. Synchronize available views by asset ID and time window.
    2. Construct the relational graph from documented asset/proxy relations.
    3. For each training epoch: encode each view; decompose latent features
       into health/context/residual components; compute orthogonality and
       reconstruction losses; perform cross-modal contrastive alignment;
       apply graph propagation; fuse representations; predict classification
       and RUL (and risk if configured); compute the applicable losses
       including trajectory consistency; and update theta using Adam/AdamW.
    4. Return theta.

Step 1 ("synchronize by asset ID and time window") is handled upstream by
`data.CMAPSSWindowDataset`, which builds each sample from a single
engine's single window so all views are already aligned. Step 2 (graph
construction) is handled per-batch inside `C3MFarm.forward` via
`graph.build_adjacency`, treating each mini-batch as the node set V (a
documented, batch-local proxy graph -- see graph.py).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import torch
from torch.utils.data import DataLoader

from .config import C3MFarmConfig
from .model import C3MFarm


@dataclass
class EpochStats:
    train_loss: float
    val_loss: Optional[float] = None


def _move_batch(batch: Dict[str, torch.Tensor], device: torch.device) -> Dict[str, torch.Tensor]:
    return {k: v.to(device) for k, v in batch.items()}


def _split_views_and_targets(batch: Dict[str, torch.Tensor]):
    target_keys = {"rul", "fault_label", "unit", "end_cycle"}
    views = {k: v for k, v in batch.items() if k not in target_keys}
    return views, batch


def train_one_epoch(
    model: C3MFarm,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> float:
    model.train()
    total_loss, n_batches = 0.0, 0
    for batch in loader:
        batch = _move_batch(batch, device)
        views, targets = _split_views_and_targets(batch)

        optimizer.zero_grad()
        h_current, z_h, z_e, z_c = model.encode_and_disentangle(views)
        out = model.forward(views)

        cls_targets = targets["fault_label"] if (targets["fault_label"] >= 0).all() else None
        rul_targets = targets.get("rul")

        losses = model.compute_losses(
            out,
            h_current=h_current,
            cls_targets=cls_targets,
            rul_targets=rul_targets,
            future_pooled_health=None,  # see train_with_trajectory() for the Delta-shifted variant
        )
        losses.total.backward()
        optimizer.step()

        total_loss += losses.total.item()
        n_batches += 1
    return total_loss / max(n_batches, 1)


@torch.no_grad()
def evaluate(model: C3MFarm, loader: DataLoader, device: torch.device) -> float:
    model.eval()
    total_loss, n_batches = 0.0, 0
    for batch in loader:
        batch = _move_batch(batch, device)
        views, targets = _split_views_and_targets(batch)
        h_current, z_h, z_e, z_c = model.encode_and_disentangle(views)
        out = model.forward(views)
        cls_targets = targets["fault_label"] if (targets["fault_label"] >= 0).all() else None
        rul_targets = targets.get("rul")
        losses = model.compute_losses(out, h_current=h_current, cls_targets=cls_targets, rul_targets=rul_targets)
        total_loss += losses.total.item()
        n_batches += 1
    return total_loss / max(n_batches, 1)


def fit(
    config: C3MFarmConfig,
    train_loader: DataLoader,
    val_loader: Optional[DataLoader] = None,
    device: Optional[torch.device] = None,
) -> Dict[str, object]:
    """Runs Algorithm 1 end to end and returns the trained model plus history.

    Early stopping monitors validation loss with patience
    `config.early_stopping_patience` (a documented default -- the paper
    reports "early stopping on validation loss" without a numeric
    patience value, per Sec. 3.1/Table 2 notes).
    """
    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(config.random_seed)

    model = C3MFarm(config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)

    history = []
    best_val = float("inf")
    best_state = None
    patience_left = config.early_stopping_patience

    for epoch in range(config.num_epochs):
        train_loss = train_one_epoch(model, train_loader, optimizer, device)
        val_loss = evaluate(model, val_loader, device) if val_loader is not None else None
        history.append(EpochStats(train_loss, val_loss))

        if val_loader is not None:
            if val_loss < best_val:
                best_val = val_loss
                best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
                patience_left = config.early_stopping_patience
            else:
                patience_left -= 1
                if patience_left <= 0:
                    break

    if best_state is not None:
        model.load_state_dict(best_state)

    return {"model": model, "history": history, "best_val_loss": best_val if val_loader is not None else None}
