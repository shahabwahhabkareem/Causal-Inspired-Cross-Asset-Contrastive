"""
Total optimization objective (Eq. 24, Sec. 3.3):

    L_total^(reported) = lambda_1 L_cmc + lambda_2 L_orth + lambda_3 L_rec
                        + lambda_4 L_cls + lambda_5 L_rul + lambda_7 L_traj

For the reported C-MAPSS proxy experiment, lambda_6 = 0 and L_risk is
excluded (no calibrated risk labels/horizon are documented). This module
mirrors that: `risk_loss_value` and `lambda_risk` are only added to the
total when `config.use_risk_head` is True.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import torch

from .config import C3MFarmConfig


@dataclass
class LossBreakdown:
    total: torch.Tensor
    cmc: torch.Tensor
    orth: torch.Tensor
    rec: torch.Tensor
    cls: torch.Tensor
    rul: torch.Tensor
    traj: torch.Tensor
    risk: Optional[torch.Tensor] = None

    def as_dict(self) -> Dict[str, float]:
        d = {
            "total": self.total.item(),
            "cmc": self.cmc.item(),
            "orth": self.orth.item(),
            "rec": self.rec.item(),
            "cls": self.cls.item(),
            "rul": self.rul.item(),
            "traj": self.traj.item(),
        }
        if self.risk is not None:
            d["risk"] = self.risk.item()
        return d


def composite_loss(
    config: C3MFarmConfig,
    l_cmc: torch.Tensor,
    l_orth: torch.Tensor,
    l_rec: torch.Tensor,
    l_cls: torch.Tensor,
    l_rul: torch.Tensor,
    l_traj: torch.Tensor,
    l_risk: Optional[torch.Tensor] = None,
) -> LossBreakdown:
    total = (
        config.lambda_cmc * l_cmc
        + config.lambda_orth * l_orth
        + config.lambda_rec * l_rec
        + config.lambda_cls * l_cls
        + config.lambda_rul * l_rul
        + config.lambda_traj * l_traj
    )
    if config.use_risk_head and l_risk is not None and config.lambda_risk > 0:
        total = total + config.lambda_risk * l_risk
    else:
        l_risk = None
    return LossBreakdown(total, l_cmc, l_orth, l_rec, l_cls, l_rul, l_traj, l_risk)
