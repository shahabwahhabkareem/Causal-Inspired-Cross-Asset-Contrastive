"""
Stage 4 -- predictive-maintenance fusion (Eq. 13-15, Sec. 3.3).

    u_i = psi(z_i,h, z_i,e, z_i,c, g_i)                                          (13)

    e_ik = w_a^T tanh(W_a r_ik + b_a),  beta_ik = softmax_k(e_ik)                 (14)

    u_i = sum_k beta_ik * r_ik                                                   (15)

`psi` is realized as attention pooling over the candidate representation
set {z_i,h, z_i,e, z_i,c, g_i} (r_ik), each already living in
R^{subspace_dim} so they can be attention-pooled directly.
"""
from __future__ import annotations

from typing import List

import torch
import torch.nn as nn


class AttentionFusion(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.W_a = nn.Linear(dim, dim, bias=True)
        self.w_a = nn.Linear(dim, 1, bias=False)

    def forward(self, candidates: List[torch.Tensor]) -> torch.Tensor:
        """candidates: list of K tensors, each (B, dim). Returns u_i: (B, dim)."""
        R = torch.stack(candidates, dim=1)  # (B, K, dim)
        e = self.w_a(torch.tanh(self.W_a(R))).squeeze(-1)  # (B, K), Eq. 14
        beta = torch.softmax(e, dim=-1)  # (B, K)
        u = torch.sum(beta.unsqueeze(-1) * R, dim=1)  # (B, dim), Eq. 15
        return u
