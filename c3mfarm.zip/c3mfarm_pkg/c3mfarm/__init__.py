"""
c3mfarm: reference implementation of C3M-Farm.

Causal-Inspired Cross-Asset Contrastive Multimodal Maintenance Network,
evaluated as a NASA C-MAPSS turbofan-prognostics proxy benchmark for
renewable-energy predictive maintenance.

See README.md for the equation-by-module map and the paper's documented
limitations (proxy modalities, unaudited synthetic-text leakage-safety,
synthetic/constructed proxy graph, non-identified causal interpretation).
"""
from .config import C3MFarmConfig
from .model import C3MFarm, C3MFarmOutput
from .losses import LossBreakdown, composite_loss
from .train import fit

__all__ = [
    "C3MFarmConfig",
    "C3MFarm",
    "C3MFarmOutput",
    "LossBreakdown",
    "composite_loss",
    "fit",
]

__version__ = "0.1.0"
