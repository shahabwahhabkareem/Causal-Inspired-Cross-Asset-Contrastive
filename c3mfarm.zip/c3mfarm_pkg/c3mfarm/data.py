"""
NASA C-MAPSS proxy-benchmark data pipeline (Sec. 4.1).

The paper is explicit that C-MAPSS is used as a *turbofan-prognostics
proxy* for renewable-energy-farm maintenance, not as direct validation:
    - "s" (sensor) and "w" (operating settings / weather-context) are the
      only views measured directly by C-MAPSS;
    - "v" (STFT spectral) and "l" (synthetic text) are *derived* proxy
      views built from the native sensor/setting columns, so they are not
      independent measurement modalities;
    - the proxy relational graph (Sec. 3.2, Eq. 10) has no geographic or
      electrical-topology counterpart in C-MAPSS.

Per Sec. 4.1/4.6, the exact window stride, STFT parameters, and
synthetic-text generation rule used in the archived experiment are *not*
preserved. The implementations below are therefore original, documented,
train-only-safe constructions -- not a reproduction of the original
(unspecified) procedure. Anything derived using this pipeline should be
reported as using *this* documented construction, not the paper's.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

# Standard C-MAPSS column layout: unit, cycle, 3 operating settings, 21 sensors.
_COLUMNS = (
    ["unit", "cycle", "op_setting_1", "op_setting_2", "op_setting_3"]
    + [f"sensor_{i}" for i in range(1, 22)]
)

# Sensors commonly reported as informative / non-constant for FD00x subsets.
DEFAULT_SENSOR_COLS = [
    "sensor_2", "sensor_3", "sensor_4", "sensor_7", "sensor_8", "sensor_9",
    "sensor_11", "sensor_12", "sensor_13", "sensor_14", "sensor_15",
    "sensor_17", "sensor_20", "sensor_21",
]
OP_SETTING_COLS = ["op_setting_1", "op_setting_2", "op_setting_3"]


def load_cmapss_train(path: str) -> pd.DataFrame:
    """Loads a raw `train_FD00X.txt` file (whitespace-separated, no header)."""
    df = pd.read_csv(path, sep=r"\s+", header=None)
    df = df.iloc[:, : len(_COLUMNS)]
    df.columns = _COLUMNS
    return df


def add_rul_labels(df: pd.DataFrame, rul_cap: Optional[int] = 125) -> pd.DataFrame:
    """Adds a `RUL` column: (max_cycle_for_unit - cycle), optionally clipped.

    A piecewise-linear (capped) RUL target is a standard, widely used
    C-MAPSS convention; `rul_cap=None` disables capping.
    """
    df = df.copy()
    max_cycle = df.groupby("unit")["cycle"].transform("max")
    rul = max_cycle - df["cycle"]
    if rul_cap is not None:
        rul = rul.clip(upper=rul_cap)
    df["RUL"] = rul.astype(float)
    return df


def add_binary_fault_label(df: pd.DataFrame, rul_threshold: int = 30) -> pd.DataFrame:
    """Binary proxy fault label: 1 if RUL <= threshold ('approaching failure'), else 0.

    This is a documented convention adopted for this implementation to
    obtain a classification target from C-MAPSS (which has no native
    fault-class labels); report it explicitly as such.
    """
    df = df.copy()
    if "RUL" not in df.columns:
        df = add_rul_labels(df)
    df["fault_label"] = (df["RUL"] <= rul_threshold).astype(int)
    return df


def engine_disjoint_split(
    df: pd.DataFrame, val_frac: float = 0.2, seed: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Splits by whole engine (unit) ID so no engine's cycles appear in both
    train and validation -- the "engine-disjoint grouped split" the paper
    uses for its controlled comparison (Sec. 4.1), as opposed to a random
    row-level split which would leak future cycles of the same engine.
    """
    rng = np.random.default_rng(seed)
    units = df["unit"].unique()
    rng.shuffle(units)
    n_val = max(1, int(len(units) * val_frac))
    val_units = set(units[:n_val])
    train_df = df[~df["unit"].isin(val_units)].reset_index(drop=True)
    val_df = df[df["unit"].isin(val_units)].reset_index(drop=True)
    return train_df, val_df


def minmax_fit(df: pd.DataFrame, cols: List[str]) -> Dict[str, Tuple[float, float]]:
    """Fits per-column min/max on TRAINING data only (avoids test leakage)."""
    stats = {}
    for c in cols:
        stats[c] = (float(df[c].min()), float(df[c].max()))
    return stats


def minmax_apply(df: pd.DataFrame, cols: List[str], stats: Dict[str, Tuple[float, float]]) -> pd.DataFrame:
    df = df.copy()
    for c in cols:
        lo, hi = stats[c]
        span = hi - lo if hi > lo else 1.0
        df[c] = (df[c] - lo) / span
    return df


def _stft_view(window: np.ndarray, n_fft: int = 32, hop: int = 8, out_dim: int = 64) -> np.ndarray:
    """Derives a fixed-size STFT-magnitude spectral proxy view from a sensor
    window (Sec. 4.1: "spectral views were produced using the STFT").

    `window`: (L, C) sensor array for one sample.
    Returns a flattened, size-`out_dim` magnitude-spectrum summary
    (averaged across channels then across time frames beyond `out_dim`),
    computed independently per sample from *only that sample's* current/
    past window -- i.e. train-only-safe by construction, no look-ahead.
    """
    L, C = window.shape
    sig = window.mean(axis=1)  # collapse channels -> a single representative trace
    n_fft = min(n_fft, L)
    spec_frames = []
    for start in range(0, max(L - n_fft, 0) + 1, hop):
        frame = sig[start:start + n_fft]
        if len(frame) < n_fft:
            frame = np.pad(frame, (0, n_fft - len(frame)))
        windowed = frame * np.hanning(n_fft)
        mag = np.abs(np.fft.rfft(windowed))
        spec_frames.append(mag)
    if not spec_frames:
        spec_frames = [np.zeros(n_fft // 2 + 1)]
    spec = np.stack(spec_frames, axis=0).mean(axis=0)  # average magnitude over time frames
    if len(spec) >= out_dim:
        spec = spec[:out_dim]
    else:
        spec = np.pad(spec, (0, out_dim - len(spec)))
    return spec.astype(np.float32)


def _synthetic_text_view(window: np.ndarray, vocab_size: int = 32, seq_len: int = 16) -> np.ndarray:
    """Derives a synthetic "maintenance-log" token sequence from sensor
    trends *within the current window only* (Sec. 4.1 flags the original
    text-generation rule as unaudited for leakage; this implementation is
    intentionally simple and auditable: it bins the per-step mean sensor
    delta into `vocab_size` symbols).

    Uses only `window` (current/past sensor values already known at
    inference time) -- no RUL, failure-stage, or future-cycle information
    is used, so this construction is leakage-safe by inspection, though
    it is NOT a reproduction of the paper's original (undocumented) text
    generator.
    """
    L, C = window.shape
    mean_trace = window.mean(axis=1)
    deltas = np.diff(mean_trace, prepend=mean_trace[0])
    # Bin deltas into `vocab_size` symbols (reserving id 0 as padding).
    lo, hi = -1.0, 1.0
    clipped = np.clip(deltas, lo, hi)
    bins = np.linspace(lo, hi, vocab_size - 1)
    tokens = np.digitize(clipped, bins) + 1  # ids in [1, vocab_size-1]
    if len(tokens) >= seq_len:
        idx = np.linspace(0, len(tokens) - 1, seq_len).astype(int)
        tokens = tokens[idx]
    else:
        tokens = np.pad(tokens, (0, seq_len - len(tokens)))
    return tokens.astype(np.int64)


@dataclass
class CMAPSSSample:
    sensor: np.ndarray       # (L, C_s)   -> view "s"
    spectral: np.ndarray     # (out_dim,) -> view "v"
    text: np.ndarray         # (seq_len,) -> view "l"
    context: np.ndarray      # (3,)       -> view "w"
    rul: float
    fault_label: int
    unit: int
    end_cycle: int


class CMAPSSWindowDataset(Dataset):
    """Windows a (already normalized, RUL/label-augmented) C-MAPSS dataframe
    into fixed-length samples with derived multiview proxy inputs (Eq. 1).

    Windows are built per-engine so no window crosses an engine boundary.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        window_length: int = 128,
        stride: int = 1,
        sensor_cols: Optional[List[str]] = None,
        spectral_out_dim: int = 64,
        text_vocab_size: int = 32,
        text_seq_len: int = 16,
    ):
        self.window_length = window_length
        self.stride = stride
        self.sensor_cols = sensor_cols or DEFAULT_SENSOR_COLS
        self.spectral_out_dim = spectral_out_dim
        self.text_vocab_size = text_vocab_size
        self.text_seq_len = text_seq_len
        self.samples: List[CMAPSSSample] = []
        self._build(df)

    def _build(self, df: pd.DataFrame) -> None:
        for unit, g in df.groupby("unit"):
            g = g.sort_values("cycle").reset_index(drop=True)
            sensor_arr = g[self.sensor_cols].to_numpy(dtype=np.float32)
            context_arr = g[OP_SETTING_COLS].to_numpy(dtype=np.float32)
            rul_arr = g["RUL"].to_numpy(dtype=np.float32) if "RUL" in g.columns else None
            label_arr = g["fault_label"].to_numpy(dtype=np.int64) if "fault_label" in g.columns else None

            n = len(g)
            if n < self.window_length:
                continue
            for end in range(self.window_length - 1, n, self.stride):
                start = end - self.window_length + 1
                window = sensor_arr[start:end + 1]
                spectral = _stft_view(window, out_dim=self.spectral_out_dim)
                text = _synthetic_text_view(window, vocab_size=self.text_vocab_size, seq_len=self.text_seq_len)
                self.samples.append(
                    CMAPSSSample(
                        sensor=window,
                        spectral=spectral,
                        text=text,
                        context=context_arr[end],
                        rul=float(rul_arr[end]) if rul_arr is not None else float("nan"),
                        fault_label=int(label_arr[end]) if label_arr is not None else -1,
                        unit=int(unit),
                        end_cycle=int(g["cycle"].iloc[end]),
                    )
                )

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        s = self.samples[idx]
        return {
            "s": torch.from_numpy(s.sensor),
            "v": torch.from_numpy(s.spectral),
            "l": torch.from_numpy(s.text),
            "w": torch.from_numpy(s.context),
            "rul": torch.tensor(s.rul, dtype=torch.float32),
            "fault_label": torch.tensor(s.fault_label, dtype=torch.long),
            "unit": torch.tensor(s.unit, dtype=torch.long),
            "end_cycle": torch.tensor(s.end_cycle, dtype=torch.long),
        }


def collate_views(batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
    """Stacks a list of per-sample dicts (as returned by `CMAPSSWindowDataset`)
    into batched tensors, keeping the "views"/"targets" split explicit for
    `C3MFarm.forward` / `compute_losses`.
    """
    out: Dict[str, torch.Tensor] = {}
    for key in batch[0]:
        # "v" (spectral) is derived as a single dim-`out_dim` vector, not a
        # (L, C) sequence, so treat it as a static context-like view.
        out[key] = torch.stack([b[key] for b in batch], dim=0)
    if "v" in out:
        # SequenceEncoder expects (B, L, C); give the spectral summary a
        # length-1 time axis so it can reuse the same GRU encoder path.
        out["v"] = out["v"].unsqueeze(1)
    return out
