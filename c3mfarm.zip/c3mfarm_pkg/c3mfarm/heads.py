"""
Task heads (Eq. 16-23, Sec. 3.3).

Quantitatively *evaluated* in the paper: classification (Eq. 16-17) and
RUL regression (Eq. 18-19). The risk head (Eq. 20-21), urgency score
(Eq. 22), and trajectory-consistency term (Eq. 23) are implemented as
architectural extensions matching the equations, but:

  * the risk head is off by default (`config.use_risk_head = False`,
    lambda_6 = 0) because the paper reports no calibrated risk labels or
    horizon for the C-MAPSS experiment;
  * the urgency score is explicitly *not* a separately supervised task in
    the paper -- it is a decision-support score derived after prediction,
    with no urgency label, loss, or ranking metric reported. It is
    provided here only as a post-hoc scoring utility, not part of the
    optimized objective.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import C3MFarmConfig


class ClassificationHead(nn.Module):
    """y_hat_i^cls = softmax(W_cls u_i + b_cls)   (Eq. 16)"""

    def __init__(self, in_dim: int, num_classes: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, num_classes)

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        return self.linear(u)  # return logits; use classification_loss for Eq. 17


def classification_loss(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    """L_cls, Eq. 17 (cross-entropy; `targets` are class indices, not one-hot)."""
    return F.cross_entropy(logits, targets)


class RULHead(nn.Module):
    """r_hat_i = W_rul u_i + b_rul   (Eq. 18)"""

    def __init__(self, in_dim: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, 1)

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        return self.linear(u).squeeze(-1)


def rul_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """L_rul, Eq. 19 (MSE)."""
    return F.mse_loss(pred, target)


class RiskHead(nn.Module):
    """p_hat_i = sigmoid(W_risk u_i + b_risk)   (Eq. 20)

    Architectural extension only -- see module docstring. Disabled unless
    `config.use_risk_head` is True *and* calibrated risk labels/horizon
    are supplied by the caller.
    """

    def __init__(self, in_dim: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, 1)

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.linear(u)).squeeze(-1)


def risk_loss(pred_prob: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """L_risk, Eq. 21 (binary cross-entropy on probabilities)."""
    return F.binary_cross_entropy(pred_prob.clamp(1e-7, 1 - 1e-7), target.float())


class UrgencyScore(nn.Module):
    """y_hat_i^urg = sigmoid(W_urg u_i + b_urg)   (Eq. 22)

    Post-hoc decision-support score only. Not trained with a dedicated
    loss and not evaluated with ranking metrics in the paper (no
    Precision@k / nDCG are reported) -- do not treat this as a validated
    prioritization signal without your own labels and evaluation.
    """

    def __init__(self, in_dim: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, 1)

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.linear(u)).squeeze(-1)


class TrajectoryPredictor(nn.Module):
    """Predicts the future health embedding z_hat_{i,t+Delta}^h from (z_h, z_e) at t.

    Used with `trajectory_loss` for Eq. 23. This is a predictive
    regularizer over factual future trajectories (C-MAPSS has no
    maintenance interventions), not a counterfactual/causal-effect
    estimator -- see Sec. 3.3.
    """

    def __init__(self, subspace_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(subspace_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, subspace_dim),
        )

    def forward(self, z_h_t: torch.Tensor, z_e_t: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([z_h_t, z_e_t], dim=-1))


def trajectory_loss(pred_future_h: torch.Tensor, true_future_h: torch.Tensor) -> torch.Tensor:
    """L_traj, Eq. 23 (squared L2 norm, averaged over the batch)."""
    return torch.mean(torch.sum((pred_future_h - true_future_h) ** 2, dim=-1))


def build_heads(config: C3MFarmConfig) -> nn.ModuleDict:
    dim = config.fused_dim
    heads = {
        "cls": ClassificationHead(dim, config.num_classes),
        "rul": RULHead(dim),
        "urgency": UrgencyScore(dim),
        "traj": TrajectoryPredictor(config.subspace_dim, config.encoder_hidden_dim, config.dropout),
    }
    if config.use_risk_head:
        heads["risk"] = RiskHead(dim)
    return nn.ModuleDict(heads)
