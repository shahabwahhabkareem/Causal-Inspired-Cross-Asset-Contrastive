"""
Stage 2 -- environment-aware latent disentanglement (Eq. 4-6, Sec. 3.2/3.2.1).

    z_i,h^m = g_h^m(h_i^m),  z_i,e^m = g_e^m(h_i^m),  z_i,c^m = g_c^m(h_i^m)     (4)

    L_orth = (1/M) * sum_m || (Z_h^m)^T Z_e^m ||_F^2                            (5)

    L_rec  = (1/M) * sum_m || h_i^m - D_m([z_i,h^m ; z_i,e^m ; z_i,c^m]) ||_2^2  (6)

Per Sec. 3.2.1, this decomposition is *causal-inspired* (motivated by a
hypothesized health/context/action structural story) but is not claimed
to identify causal variables from purely observational data; the losses
below are ordinary decorrelation/reconstruction regularizers, not a
causal-discovery procedure.
"""
from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn as nn

from .config import C3MFarmConfig


class DisentangleHead(nn.Module):
    """The three projection heads g_h^m, g_e^m, g_c^m for a single modality m."""

    def __init__(self, hidden_dim: int, subspace_dim: int, dropout: float):
        super().__init__()

        def _head():
            return nn.Sequential(
                nn.Linear(hidden_dim, subspace_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(subspace_dim, subspace_dim),
            )

        self.g_h = _head()  # health-related
        self.g_e = _head()  # environment/context-related
        self.g_c = _head()  # residual

    def forward(self, h: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return self.g_h(h), self.g_e(h), self.g_c(h)


class ModalityDecoder(nn.Module):
    """D_m: reconstructs h_i^m from the concatenated [z_h ; z_e ; z_c] (Eq. 6)."""

    def __init__(self, subspace_dim: int, hidden_dim: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(subspace_dim * 3, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(self, z_h: torch.Tensor, z_e: torch.Tensor, z_c: torch.Tensor) -> torch.Tensor:
        z = torch.cat([z_h, z_e, z_c], dim=-1)
        return self.net(z)


def build_disentangle_modules(config: C3MFarmConfig) -> Tuple[nn.ModuleDict, nn.ModuleDict]:
    heads, decoders = {}, {}
    for m in config.active_modalities:
        if config.input_dims.get(m, 0) <= 0:
            continue
        heads[m] = DisentangleHead(config.encoder_hidden_dim, config.subspace_dim, config.dropout)
        decoders[m] = ModalityDecoder(config.subspace_dim, config.encoder_hidden_dim, config.dropout)
    return nn.ModuleDict(heads), nn.ModuleDict(decoders)


def orthogonality_loss(z_h: Dict[str, torch.Tensor], z_e: Dict[str, torch.Tensor]) -> torch.Tensor:
    """Eq. 5, averaged over the M active modalities.

    Z_h^m, Z_e^m are batch matrices (B, subspace_dim) for modality m.
    """
    losses = []
    for m in z_h:
        zh, ze = z_h[m], z_e[m]
        cross = zh.transpose(0, 1) @ ze  # (subspace_dim, subspace_dim)
        losses.append(torch.linalg.matrix_norm(cross, ord="fro") ** 2)
    if not losses:
        return torch.tensor(0.0)
    return torch.stack(losses).mean() / zh.shape[0] ** 2  # normalize by batch size for scale stability


def reconstruction_loss(
    h: Dict[str, torch.Tensor],
    z_h: Dict[str, torch.Tensor],
    z_e: Dict[str, torch.Tensor],
    z_c: Dict[str, torch.Tensor],
    decoders: nn.ModuleDict,
) -> torch.Tensor:
    """Eq. 6, averaged over the M active modalities."""
    losses = []
    for m in h:
        recon = decoders[m](z_h[m], z_e[m], z_c[m])
        losses.append(torch.mean(torch.sum((h[m] - recon) ** 2, dim=-1)))
    if not losses:
        return torch.tensor(0.0)
    return torch.stack(losses).mean()
