"""
C3M-Farm: end-to-end model (Sec. 3.1-3.3, Eq. 1-24 collectively).

    f_theta(X_i(t), G) = (y_hat_i^cls, r_hat_i, p_hat_{i,t+Delta}, u_hat_i)   (3)

This module wires together the four stages described in Sec. 3.1:
  1. modality-specific encoding                (encoders.py, Eq. 1-2)
  2. environment-aware disentanglement           (disentangle.py, Eq. 4-6)
  3. cross-modal contrastive + graph reasoning   (contrastive.py, graph.py, Eq. 7-12)
  4. attention fusion + task heads               (fusion.py, heads.py, Eq. 13-23)

`forward()` returns both the task predictions (Eq. 3) and every
intermediate quantity needed to compute the training losses in
`losses.py`, so a single forward pass suffices for one optimization step
(see `train.py`, which implements Algorithm 1).

As emphasized throughout the paper, in the C-MAPSS proxy benchmark the
graph G is a synthetic/constructed relational structure over
operating-condition similarity -- not a physical renewable-farm
topology -- and the disentanglement/contrastive machinery is
causal-inspired rather than causally identified. Nothing in this module
changes that interpretation; it only implements the stated equations.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import torch
import torch.nn as nn

from .config import C3MFarmConfig
from .encoders import build_encoders
from .disentangle import build_disentangle_modules
from .contrastive import cross_modal_contrastive_loss
from .graph import build_adjacency, GraphModule
from .fusion import AttentionFusion
from .heads import build_heads, classification_loss, rul_loss, trajectory_loss
from .disentangle import orthogonality_loss, reconstruction_loss
from .losses import composite_loss, LossBreakdown


@dataclass
class C3MFarmOutput:
    logits_cls: torch.Tensor
    rul_pred: torch.Tensor
    urgency_score: torch.Tensor
    fused_embedding: torch.Tensor          # u_i, Eq. 13/15
    risk_prob: Optional[torch.Tensor]      # p_hat_i, Eq. 20 (None unless enabled)
    z_health: Dict[str, torch.Tensor]      # per-modality health latents, for L_cmc / L_traj
    z_env: Dict[str, torch.Tensor]
    z_res: Dict[str, torch.Tensor]
    pooled_health: torch.Tensor            # mean over modalities -> z_i,h in Eq. 13
    pooled_env: torch.Tensor
    pooled_res: torch.Tensor
    graph_repr: torch.Tensor               # g_i, Eq. 12


class C3MFarm(nn.Module):
    def __init__(self, config: C3MFarmConfig):
        super().__init__()
        self.config = config
        self.encoders = build_encoders(config)
        self.disentangle_heads, self.decoders = build_disentangle_modules(config)
        self.graph = GraphModule(config)
        self.fusion = AttentionFusion(config.subspace_dim)
        self.heads = build_heads(config)

    def encode_and_disentangle(self, views: Dict[str, torch.Tensor]):
        """Runs Stage 1 + Stage 2 only. Returns (h, z_h, z_e, z_c) dicts.

        Exposed separately because the trajectory-consistency loss (Eq. 23)
        needs the same encode+disentangle pipeline applied to a *future*
        window, without re-running graph/fusion/heads.
        """
        h, z_h, z_e, z_c = {}, {}, {}, {}
        for m, encoder in self.encoders.items():
            if m not in views:
                continue
            h_m = encoder(views[m])
            h[m] = h_m
            zh, ze, zc = self.disentangle_heads[m](h_m)
            z_h[m], z_e[m], z_c[m] = zh, ze, zc
        return h, z_h, z_e, z_c

    def forward(self, views: Dict[str, torch.Tensor], adjacency: Optional[torch.Tensor] = None) -> C3MFarmOutput:
        """
        views: mapping modality -> raw batch tensor for the *current* window.
            - "s"/"v"/"a": (B, L, C)
            - "l": (B, T) token ids
            - "w": (B, d_w)
        adjacency: optional precomputed (B, B) proxy graph; if None, one is
            built from the "w" (operating-condition/context) view via
            `graph.build_adjacency`, matching Eq. 10 with alpha_geo =
            alpha_elec = 0 by default (see config.py).
        """
        h, z_h, z_e, z_c = self.encode_and_disentangle(views)

        # Stage 4 needs a single per-asset health/env/residual vector; pool
        # across active modalities (mean), consistent with treating
        # z_i,h / z_i,e / z_i,c in Eq. 13 as asset-level (not per-modality)
        # quantities once cross-modal alignment has been applied.
        pooled_h = torch.stack(list(z_h.values()), dim=0).mean(dim=0)
        pooled_e = torch.stack(list(z_e.values()), dim=0).mean(dim=0)
        pooled_c = torch.stack(list(z_c.values()), dim=0).mean(dim=0)

        if adjacency is None:
            if "w" not in views:
                raise ValueError(
                    "No adjacency supplied and no 'w' (context) view available to build one "
                    "from CondSim; pass `adjacency` explicitly."
                )
            adjacency = build_adjacency(
                context=views["w"],
                alpha_geo=self.config.alpha_geo,
                alpha_cond=self.config.alpha_cond,
                alpha_elec=self.config.alpha_elec,
                knn_k=self.config.graph_knn_k,
                self_loops=self.config.graph_self_loops,
            )

        node_features = torch.cat([pooled_h, pooled_e, pooled_c], dim=-1)  # n_i, Sec. 3.2
        g_i = self.graph(node_features, adjacency)  # Eq. 12

        u_i = self.fusion([pooled_h, pooled_e, pooled_c, g_i])  # Eq. 13-15

        logits_cls = self.heads["cls"](u_i)          # Eq. 16
        rul_pred = self.heads["rul"](u_i)             # Eq. 18
        urgency = self.heads["urgency"](u_i)          # Eq. 22 (post-hoc, unsupervised here)
        risk_prob = self.heads["risk"](u_i) if "risk" in self.heads else None  # Eq. 20

        return C3MFarmOutput(
            logits_cls=logits_cls,
            rul_pred=rul_pred,
            urgency_score=urgency,
            fused_embedding=u_i,
            risk_prob=risk_prob,
            z_health=z_h,
            z_env=z_e,
            z_res=z_c,
            pooled_health=pooled_h,
            pooled_env=pooled_e,
            pooled_res=pooled_c,
            graph_repr=g_i,
        )

    def predict_future_health(self, pooled_h_t: torch.Tensor, pooled_e_t: torch.Tensor) -> torch.Tensor:
        """z_hat_{i,t+Delta}^h for the trajectory-consistency loss (Eq. 23)."""
        return self.heads["traj"](pooled_h_t, pooled_e_t)

    def compute_losses(
        self,
        out: C3MFarmOutput,
        h_current: Dict[str, torch.Tensor],
        cls_targets: Optional[torch.Tensor] = None,
        rul_targets: Optional[torch.Tensor] = None,
        future_pooled_health: Optional[torch.Tensor] = None,
        risk_targets: Optional[torch.Tensor] = None,
    ) -> LossBreakdown:
        """Assembles every term of Eq. 24 from one forward pass's outputs.

        `future_pooled_health` (B, subspace_dim) is the *target* future
        health embedding (pooled_health computed by a second forward pass
        on the window at t+Delta); if provided, the trajectory loss and
        the trajectory predictor are used together.
        """
        l_cmc = cross_modal_contrastive_loss(out.z_health, self.config.contrastive_temperature)
        l_orth = orthogonality_loss(out.z_health, out.z_env)
        l_rec = reconstruction_loss(h_current, out.z_health, out.z_env, out.z_res, self.decoders)

        l_cls = classification_loss(out.logits_cls, cls_targets) if cls_targets is not None else torch.tensor(0.0)
        l_rul = rul_loss(out.rul_pred, rul_targets) if rul_targets is not None else torch.tensor(0.0)

        if future_pooled_health is not None:
            pred_future_h = self.predict_future_health(out.pooled_health, out.pooled_env)
            l_traj = trajectory_loss(pred_future_h, future_pooled_health)
        else:
            l_traj = torch.tensor(0.0)

        l_risk = None
        if out.risk_prob is not None and risk_targets is not None:
            from .heads import risk_loss as _risk_loss
            l_risk = _risk_loss(out.risk_prob, risk_targets)

        return composite_loss(self.config, l_cmc, l_orth, l_rec, l_cls, l_rul, l_traj, l_risk)
