"""
Stage 3b -- cross-asset graph reasoning (Eq. 10-12, Sec. 3.2).

    n_i = [z_i,h ; z_i,e ; z_i,c]                                               (node feature)

    A_ij = alpha_1 * GeoSim(i,j) + alpha_2 * CondSim(i,j) + alpha_3 * ElecConn(i,j)   (10)

    N^(l+1) = sigma( D~^{-1/2} A~ D~^{-1/2} N^(l) W^(l) )                        (11)

    g_i = f_graph(n_i, G)                                                       (12)

IMPORTANT (see Sec. 3.2 / paper's "Reproducible graph requirement"):
C-MAPSS provides no geographic positions or electrical topology, so
GeoSim and ElecConn cannot be computed from this dataset; they are
implemented here as pluggable functions that return zero by default.
CondSim (operating-condition similarity) *can* be computed from C-MAPSS
operating settings and is the only physically meaningful proxy signal
available -- this is a synthetic/constructed relational structure, not a
physical farm network, and is treated as such throughout this module and
in `config.py`.
"""
from __future__ import annotations

from typing import Callable, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import C3MFarmConfig

SimilarityFn = Callable[[torch.Tensor], torch.Tensor]


def cond_sim(context: torch.Tensor) -> torch.Tensor:
    """CondSim(i,j): operating-condition similarity from context/weather vectors.

    context: (N, d_w) batch of operating-setting vectors.
    Returns an (N, N) similarity matrix in [0, 1] via a Gaussian RBF kernel
    on standardized context vectors. This is the *only* physically
    meaningful analogue available in C-MAPSS; it is not geographic or
    electrical information.
    """
    x = context
    x = (x - x.mean(dim=0, keepdim=True)) / (x.std(dim=0, keepdim=True) + 1e-6)
    dist2 = torch.cdist(x, x, p=2) ** 2
    gamma = 1.0 / max(x.shape[1], 1)
    return torch.exp(-gamma * dist2)


def zero_sim(context: torch.Tensor) -> torch.Tensor:
    """Placeholder for GeoSim / ElecConn: returns an all-zero (N, N) matrix.

    Use this (the default) whenever the dataset does not provide the
    corresponding physical relation, so it contributes nothing to Eq. 10
    rather than being silently fabricated.
    """
    n = context.shape[0]
    return torch.zeros(n, n, device=context.device, dtype=context.dtype)


def build_adjacency(
    context: torch.Tensor,
    alpha_geo: float,
    alpha_cond: float,
    alpha_elec: float,
    knn_k: Optional[int] = None,
    geo_sim_fn: SimilarityFn = zero_sim,
    cond_sim_fn: SimilarityFn = cond_sim,
    elec_sim_fn: SimilarityFn = zero_sim,
    self_loops: bool = True,
) -> torch.Tensor:
    """Constructs A_ij per Eq. 10 and, optionally, sparsifies it with k-NN.

    Returns A (already including self-loops if requested, i.e. A~ = A + I
    from Eq. 11) as a dense (N, N) tensor. For batch sizes typical of
    mini-batch training this dense form is adequate; swap in a sparse
    adjacency for large asset fleets.
    """
    geo = geo_sim_fn(context)
    cond = cond_sim_fn(context)
    elec = elec_sim_fn(context)
    A = alpha_geo * geo + alpha_cond * cond + alpha_elec * elec

    if knn_k is not None and knn_k < A.shape[0]:
        topk = torch.topk(A, k=knn_k, dim=-1)
        mask = torch.zeros_like(A)
        mask.scatter_(1, topk.indices, 1.0)
        mask = torch.maximum(mask, mask.transpose(0, 1))  # symmetrize
        A = A * mask

    A.fill_diagonal_(0.0)
    if self_loops:
        A = A + torch.eye(A.shape[0], device=A.device, dtype=A.dtype)
    return A


def normalize_adjacency(A: torch.Tensor) -> torch.Tensor:
    """D~^{-1/2} A~ D~^{-1/2}, the symmetric-normalization term in Eq. 11."""
    deg = A.sum(dim=-1)
    d_inv_sqrt = torch.pow(deg.clamp(min=1e-8), -0.5)
    D_inv_sqrt = torch.diag(d_inv_sqrt)
    return D_inv_sqrt @ A @ D_inv_sqrt


class GCNLayer(nn.Module):
    """One propagation step of Eq. 11."""

    def __init__(self, in_dim: int, out_dim: int, dropout: float):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, N: torch.Tensor, A_norm: torch.Tensor) -> torch.Tensor:
        out = A_norm @ self.linear(N)
        return self.drop(F.gelu(out))


class GraphModule(nn.Module):
    """f_graph: stacks L_g GCN layers to produce g_i from node features n_i (Eq. 12)."""

    def __init__(self, config: C3MFarmConfig):
        super().__init__()
        node_dim = config.subspace_dim * 3  # [z_h ; z_e ; z_c]
        dims = [node_dim] + [config.graph_hidden_dim] * config.num_graph_layers
        self.layers = nn.ModuleList(
            [GCNLayer(dims[i], dims[i + 1], config.dropout) for i in range(config.num_graph_layers)]
        )
        self.out_proj = nn.Linear(dims[-1], config.subspace_dim)
        self.config = config

    def forward(self, node_features: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        A_norm = normalize_adjacency(adjacency)
        N = node_features
        for layer in self.layers:
            N = layer(N, A_norm)
        return self.out_proj(N)
