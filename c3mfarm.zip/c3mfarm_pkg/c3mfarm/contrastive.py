"""
Stage 3a -- cross-modal contrastive alignment (Eq. 7-9, Sec. 3.2).

    sim(u, v) = u^T v / (||u||_2 ||v||_2)                                       (7)

    L_cmc^(m,n) = -(1/B) sum_i log[ exp(sim(z_i,h^m, z_i,h^n)/tau)
                                     / sum_j exp(sim(z_i,h^m, z_j,h^n)/tau) ]    (8)

    L_cmc = (1/|P|) sum_{(m,n) in P} L_cmc^(m,n)                                (9)

Positive pairs are same-asset, same-time-window views across modalities;
negatives are the other items in the mini-batch (in-batch negatives),
matching the batch-level InfoNCE formulation in Eq. 8.
"""
from __future__ import annotations

from itertools import combinations
from typing import Dict, List, Tuple

import torch
import torch.nn.functional as F


def cosine_sim_matrix(u: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """All-pairs cosine similarity between rows of u (B,d) and v (B,d) -> (B,B)."""
    u_n = F.normalize(u, dim=-1)
    v_n = F.normalize(v, dim=-1)
    return u_n @ v_n.transpose(0, 1)


def pairwise_cmc_loss(z_m: torch.Tensor, z_n: torch.Tensor, temperature: float) -> torch.Tensor:
    """L_cmc^(m,n), Eq. 8. Symmetrized over the (m->n) and (n->m) directions."""
    sims = cosine_sim_matrix(z_m, z_n) / temperature  # (B, B)
    targets = torch.arange(sims.shape[0], device=sims.device)
    loss_mn = F.cross_entropy(sims, targets)
    loss_nm = F.cross_entropy(sims.transpose(0, 1), targets)
    return 0.5 * (loss_mn + loss_nm)


def cross_modal_contrastive_loss(
    z_health: Dict[str, torch.Tensor],
    temperature: float,
    modality_pairs: List[Tuple[str, str]] | None = None,
) -> torch.Tensor:
    """L_cmc, Eq. 9, averaged over the modality-pair set P.

    Parameters
    ----------
    z_health: mapping modality -> health-related batch embeddings (B, subspace_dim).
    modality_pairs: the set P of modality pairs to align; defaults to all
        pairs among the modalities present in `z_health`.
    """
    modalities = list(z_health.keys())
    if len(modalities) < 2:
        return torch.tensor(0.0, device=next(iter(z_health.values())).device if z_health else "cpu")

    pairs = modality_pairs if modality_pairs is not None else list(combinations(modalities, 2))
    losses = [pairwise_cmc_loss(z_health[m], z_health[n], temperature) for m, n in pairs]
    return torch.stack(losses).mean()
