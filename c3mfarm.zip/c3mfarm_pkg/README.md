# c3mfarm

A from-scratch PyTorch implementation of **C3M-Farm** (Causal-Inspired
Cross-Asset Contrastive Multimodal Maintenance Network), as described in
*"Causal-Inspired Cross-Asset Contrastive Multimodal Maintenance
Network: A Proxy-Benchmark Study for Renewable-Energy Maintenance."*

The package implements the architecture and training objective exactly
as specified by the paper's equations, and is evaluated against NASA
C-MAPSS as a turbofan-prognostics **proxy** benchmark, matching the
paper's own framing (Sec. 4.1): this is not a validated renewable-farm
deployment.

## Install

```bash
cd c3mfarm_pkg
pip install -e .
```

## Quick start (synthetic data, sanity check)

```python
import torch
from c3mfarm import C3MFarmConfig, C3MFarm

config = C3MFarmConfig()          # Table 2 defaults
model = C3MFarm(config)

B, L = 8, config.window_length
views = {
    "s": torch.randn(B, L, config.input_dims["s"]),
    "v": torch.randn(B, 1, config.input_dims["v"]),
    "l": torch.randint(1, config.input_dims["l"], (B, 16)),
    "w": torch.randn(B, config.input_dims["w"]),
}
out = model(views)
print(out.logits_cls.shape, out.rul_pred.shape)
```

## Train on real C-MAPSS

```bash
python examples/train_cmapss.py --train_file /path/to/train_FD001.txt
```

This follows the paper's controlled comparison protocol: **engine-disjoint
grouped splits** (Sec. 4.1), train-only feature scaling, and the Table 2
hyperparameters. It does **not** reproduce the paper's archived
non-grouped 2,000-sample preliminary experiment (Tables 3-6 in the
paper), which the paper itself says must not be used for superiority
claims.

## Equation -> module map

| Paper | Equation | Module |
|---|---|---|
| Multimodal input | (1) | `data.py` (`CMAPSSWindowDataset`) |
| Modality encoders `E_m` | (2) | `encoders.py` |
| Disentanglement heads `g_h,g_e,g_c` | (4) | `disentangle.py` |
| `L_orth` | (5) | `disentangle.py::orthogonality_loss` |
| `L_rec`, decoder `D_m` | (6) | `disentangle.py::reconstruction_loss` |
| Cosine similarity | (7) | `contrastive.py::cosine_sim_matrix` |
| `L_cmc^(m,n)` | (8) | `contrastive.py::pairwise_cmc_loss` |
| `L_cmc` | (9) | `contrastive.py::cross_modal_contrastive_loss` |
| Proxy adjacency `A_ij` | (10) | `graph.py::build_adjacency` |
| GCN propagation | (11) | `graph.py::GCNLayer`, `normalize_adjacency` |
| Graph representation `g_i` | (12) | `graph.py::GraphModule` |
| Fusion operator `psi`, attention | (13)-(15) | `fusion.py::AttentionFusion` |
| Classification head, `L_cls` | (16)-(17) | `heads.py::ClassificationHead`, `classification_loss` |
| RUL head, `L_rul` | (18)-(19) | `heads.py::RULHead`, `rul_loss` |
| Risk head, `L_risk` (extension, off by default) | (20)-(21) | `heads.py::RiskHead`, `risk_loss` |
| Urgency score (post-hoc, unsupervised) | (22) | `heads.py::UrgencyScore` |
| Trajectory-consistency `L_traj` | (23) | `heads.py::TrajectoryPredictor`, `trajectory_loss` |
| Total objective `L_total` | (24) | `losses.py::composite_loss` |
| Training procedure | Algorithm 1 | `train.py::fit` |
| Hyperparameters | Table 2 | `config.py::C3MFarmConfig` |

## What this implementation is honest about

Matching the paper's own stated limitations (Sec. 3.2.1, 4.1, 4.6):

- **Proxy modalities, not independent measurements.** The "v" (spectral)
  and "l" (text) views are *derived* from the same native C-MAPSS
  sensor/setting columns (`data.py::_stft_view`, `_synthetic_text_view`),
  not independently acquired thermal/acoustic/log data. This is a
  documented, original, train-only-safe construction chosen for this
  implementation -- **it is not a reproduction of the paper's own
  (unpublished) STFT parameters or text-generation rule**, which the
  paper explicitly says were not preserved in its archived record.
- **Synthetic proxy graph, not farm topology.** `graph.py` computes
  `CondSim` (operating-condition similarity) from C-MAPSS operating
  settings; `GeoSim` and `ElecConn` default to zero because C-MAPSS has
  no geographic or electrical-topology information. `alpha_geo` /
  `alpha_elec` are exposed in `config.py` purely so a future dataset with
  real farm topology can populate them.
- **Causal-inspired, not causally identified.** The health/environment/
  residual split (`disentangle.py`) is trained with ordinary
  orthogonality + reconstruction regularizers, which do not by themselves
  identify causal variables from observational data (Sec. 3.2.1).
- **Risk head and urgency score are unvalidated extensions.** `RiskHead`
  is disabled by default (`config.use_risk_head = False`,
  `lambda_risk = 0`), matching the paper's reported experiment. The
  urgency score is a post-hoc, unsupervised-by-design output, not a
  separately trained/evaluated task -- do not use it for real
  maintenance prioritization without your own labels and evaluation.
- **Reproducibility gaps.** Window stride, random seeds, and exact
  hardware used in the paper's archived experiment are not documented
  there; this package's defaults (`config.py`) are original choices,
  recorded explicitly so *your* re-run stays auditable even where the
  paper's original one is not.

## Layout

```
c3mfarm/
  config.py        Table 2 hyperparameters
  encoders.py       Stage 1: modality encoders (Eq. 1-2)
  disentangle.py    Stage 2: disentanglement + L_orth/L_rec (Eq. 4-6)
  contrastive.py    Stage 3a: cross-modal InfoNCE (Eq. 7-9)
  graph.py          Stage 3b: proxy graph + GCN (Eq. 10-12)
  fusion.py         Stage 4: attention fusion (Eq. 13-15)
  heads.py          Task heads + their losses (Eq. 16-23)
  losses.py         Composite objective (Eq. 24)
  model.py          C3MFarm: wires stages 1-4 together (Eq. 3)
  data.py           C-MAPSS loading, windowing, proxy-view construction
  train.py          Algorithm 1 training loop
examples/train_cmapss.py   End-to-end example on real C-MAPSS data
tests/test_smoke.py        Synthetic-data forward/backward sanity checks
```
