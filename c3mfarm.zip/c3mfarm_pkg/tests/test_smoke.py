"""Smoke tests: verify shapes and gradients flow through the full pipeline
using synthetic tensors, independent of any real C-MAPSS download."""
import torch

from c3mfarm import C3MFarmConfig, C3MFarm


def make_synthetic_batch(config: C3MFarmConfig, batch_size: int = 16):
    torch.manual_seed(0)
    views = {}
    if "s" in config.active_modalities:
        views["s"] = torch.randn(batch_size, config.window_length, config.input_dims["s"])
    if "v" in config.active_modalities:
        views["v"] = torch.randn(batch_size, 1, config.input_dims["v"])
    if "l" in config.active_modalities:
        views["l"] = torch.randint(1, config.input_dims["l"], (batch_size, 16))
    if "w" in config.active_modalities:
        views["w"] = torch.randn(batch_size, config.input_dims["w"])
    return views


def test_forward_and_losses_run():
    config = C3MFarmConfig(num_epochs=1)
    model = C3MFarm(config)
    views = make_synthetic_batch(config)

    h, z_h, z_e, z_c = model.encode_and_disentangle(views)
    out = model.forward(views)

    assert out.logits_cls.shape == (16, config.num_classes)
    assert out.rul_pred.shape == (16,)
    assert out.fused_embedding.shape == (16, config.subspace_dim)

    cls_targets = torch.randint(0, config.num_classes, (16,))
    rul_targets = torch.rand(16) * 125

    # Also exercise the trajectory-consistency term with a second ("future") pass.
    future_views = make_synthetic_batch(config)
    _, future_out = model.encode_and_disentangle(future_views), model.forward(future_views)

    losses = model.compute_losses(
        out,
        h_current=h,
        cls_targets=cls_targets,
        rul_targets=rul_targets,
        future_pooled_health=future_out.pooled_health,
    )
    assert torch.isfinite(losses.total)

    losses.total.backward()
    grads = [p.grad for p in model.parameters() if p.requires_grad]
    assert any(g is not None and torch.isfinite(g).all() for g in grads)


def test_risk_head_optional():
    config = C3MFarmConfig(use_risk_head=True, lambda_risk=0.3)
    model = C3MFarm(config)
    views = make_synthetic_batch(config)
    out = model.forward(views)
    assert out.risk_prob is not None
    assert out.risk_prob.shape == (16,)


if __name__ == "__main__":
    test_forward_and_losses_run()
    test_risk_head_optional()
    print("All smoke tests passed.")
