"""
Example: train C3M-Farm on one NASA C-MAPSS subset (e.g. FD001) using an
engine-disjoint grouped split, matching the paper's controlled comparison
protocol (Sec. 4.1) -- NOT the archived non-grouped 2,000-sample setup.

Download the C-MAPSS data first, e.g. from the NASA Prognostics Data
Repository, and point --train_file at `train_FD001.txt` (or FD002/3/4).

Usage:
    python examples/train_cmapss.py --train_file /path/to/train_FD001.txt
"""
import argparse

import torch
from torch.utils.data import DataLoader

from c3mfarm import C3MFarmConfig, fit
from c3mfarm.data import (
    load_cmapss_train,
    add_rul_labels,
    add_binary_fault_label,
    engine_disjoint_split,
    minmax_fit,
    minmax_apply,
    CMAPSSWindowDataset,
    collate_views,
    DEFAULT_SENSOR_COLS,
    OP_SETTING_COLS,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_file", required=True, help="Path to train_FD00X.txt")
    parser.add_argument("--window_length", type=int, default=128)
    parser.add_argument("--rul_cap", type=int, default=125)
    parser.add_argument("--fault_rul_threshold", type=int, default=30)
    parser.add_argument("--epochs", type=int, default=100)
    args = parser.parse_args()

    df = load_cmapss_train(args.train_file)
    df = add_rul_labels(df, rul_cap=args.rul_cap)
    df = add_binary_fault_label(df, rul_threshold=args.fault_rul_threshold)

    # Engine-disjoint grouped split -- see Sec. 4.1.
    train_df, val_df = engine_disjoint_split(df, val_frac=0.2, seed=42)

    # Fit scaling stats on TRAIN engines only, then apply to both splits
    # (train-only normalization avoids validation/test leakage).
    scale_cols = DEFAULT_SENSOR_COLS + OP_SETTING_COLS
    stats = minmax_fit(train_df, scale_cols)
    train_df = minmax_apply(train_df, scale_cols, stats)
    val_df = minmax_apply(val_df, scale_cols, stats)

    train_ds = CMAPSSWindowDataset(train_df, window_length=args.window_length)
    val_ds = CMAPSSWindowDataset(val_df, window_length=args.window_length)

    config = C3MFarmConfig(num_epochs=args.epochs, window_length=args.window_length, num_classes=2)

    train_loader = DataLoader(train_ds, batch_size=config.batch_size, shuffle=True, collate_fn=collate_views)
    val_loader = DataLoader(val_ds, batch_size=config.batch_size, shuffle=False, collate_fn=collate_views)

    result = fit(config, train_loader, val_loader)
    print("Best validation loss:", result["best_val_loss"])

    torch.save(result["model"].state_dict(), "c3mfarm_trained.pt")
    print("Saved trained weights to c3mfarm_trained.pt")


if __name__ == "__main__":
    main()
