# Reproducibility protocol

## Split order

Engine IDs are split before any window is generated. A window from one engine can never appear
in more than one of train, validation, or test.

## Train-only fitting

The min-max scaler is fit only from rows belonging to training engines. Validation and test rows
are transformed using the frozen training statistics.

## Target

For a training trajectory row:

`actual_RUL = max_cycle_for_engine - current_cycle`

The reference controlled target is:

`RUL = min(125, actual_RUL)`

## Derived views

STFT and synthetic text are generated from the already-partitioned current window only.
The text generator does not use RUL or future observations.

## Raw outputs

Each run writes:

- `config_resolved.yaml`
- `history.csv`
- `predictions.csv`
- `metrics.json`
- `run_manifest.json`
- `best_model.pt`

The package cannot verify manuscript p-values unless the original paired fold/engine prediction
records are supplied. Summary p-value categories are stored as manuscript-reported facts only.
