# Manuscript-to-code mapping

| Manuscript component | Code |
|---|---|
| Eq. (2), modality encoders | `src/c3m_farm/models/encoders.py` |
| Eq. (4), latent projections | `Disentangler` |
| Eq. (5), orthogonality | `orthogonality_loss` |
| Eq. (6), reconstruction | `reconstruction_loss` |
| Eq. (7)-(9), contrastive alignment | `cross_modal_info_nce` |
| Eq. (10), conceptual adjacency | documented; C-MAPSS uses an explicit proxy k-NN graph |
| Eq. (11)-(12), graph propagation | `GraphEncoder` |
| Eq. (13)-(15), attention fusion | `AttentionFusion` |
| Eq. (16)-(21), task heads | `C3MFarm` |
| Eq. (22), urgency | `urgency_head` |
| Eq. (23), trajectory consistency | `trajectory_loss` |
| Eq. (24), total loss | `compute_total_loss` |

## Reference choices

The attached manuscript does not fully preserve the historical synthetic-text generation rule,
the historical proxy graph, archived class-label construction, or all historical STFT parameters.
This repository therefore distinguishes those missing historical details from new, explicit,
leakage-safe reference choices.

The reference text view uses only the current/past sensor window. It encodes the strongest
per-sensor trend/volatility states into deterministic tokens. It never reads RUL targets,
future cycles, or partition membership.

The reference C-MAPSS graph uses normalized operating settings inside the current batch and
connects each sample to up to `k` nearest samples from different engine IDs. It is a synthetic
relational inductive bias, not physical farm topology.
