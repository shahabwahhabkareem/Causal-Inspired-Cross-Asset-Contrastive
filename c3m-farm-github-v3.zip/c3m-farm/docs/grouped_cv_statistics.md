# Engine-grouped five-fold paired statistics

The supplied manuscript states two related but not identical evaluation protocols:

- the controlled same-pipeline result table uses engine-disjoint 70%/15%/15% splits and
  seeds 42, 123, and 456;
- the statistical test is described as paired testing on per-engine predictions with `n=5`
  folds, and five-fold grouping is performed by engine identifier.

A classical five-fold test partition necessarily holds out about 20% of engines per fold, so it
cannot simultaneously be a 15% test partition. The repository therefore does not silently
pretend the two are identical.

Two explicit protocols are supported:

```text
grouped-kfold
    Five exhaustive engine-grouped folds.
    Each engine appears in test exactly once.
    Approximately 15% of all engines are selected as an inner validation set from the
    non-test engines; the remaining engines train the model.

repeated-70-15-15
    Five deterministic engine-grouped 70/15/15 holdout repetitions.
    This preserves the controlled split proportions, but is not classical exhaustive K-fold CV.
```

For manuscript-style `n=5` paired testing, use `grouped-kfold`.

## Run

After C-MAPSS is available:

```bash
python scripts/run_grouped_cv.py \
  --data-root data/raw/CMaps \
  --output-root runs/grouped_cv \
  --protocol grouped-kfold \
  --folds 5 \
  --fold-seed 42 \
  --training-seeds 42 123 456
```

Every model receives the same immutable fold JSON file. Scaling and all other fitted
preprocessing continue to use training engines only.

## Statistics

```bash
python scripts/paired_statistics.py \
  --index runs/grouped_cv/cv_index.json \
  --output-dir artifacts/generated/grouped_cv_statistics
```

The primary Table-9-style test is a two-sided paired t-test over the five matched fold RMSE
values (`n=5`). If multiple training seeds were executed, seed RMSEs are averaged within the
same fold before the paired test.

The script also emits a secondary per-engine paired analysis using held-out-engine absolute and
squared prediction errors. It reports:

- exact p-value;
- manuscript-style label (`p < 0.01`, `p < 0.05`, or `n.s.`);
- mean paired difference;
- 95% Student-t confidence interval;
- Cohen's `dz` paired effect size.

A positive `baseline minus C3M-Farm` difference means C3M-Farm has lower error.

Generated files include:

```text
fold_seed_metrics.csv
fold_metrics_seed_averaged.csv
paired_fold_t_tests.csv
per_engine_predictions.csv
paired_engine_error_t_tests.csv
table9_regenerated.csv
STATISTICAL_PROTOCOL.json
```

These are generated experimental records. They must not be presented as preserved historical
Table 9 evidence unless they reproduce the authors' original supplementary predictions.
