# Importing a user-supplied C-MAPSS archive

If `CMAPSSData.zip` is already available locally or is uploaded into the execution environment:

```bash
python scripts/import_cmapss_archive.py \
  --archive /path/to/CMAPSSData.zip \
  --output data/raw/CMaps
```

The importer:

1. verifies that the input is a ZIP;
2. recursively extracts nested ZIP archives;
3. requires all 12 standard `train_`, `test_`, and `RUL_` files for FD001-FD004;
4. copies only those standard files into `data/raw/CMaps`;
5. records SHA-256 hashes for the source archive and extracted files in `SOURCE.json`.

The experiment matrix can then be launched without any code changes.
