# Controlled baseline source reconciliation

This repository preserves a distinction between **the configuration stated in the C3M-Farm
controlled comparison** and **the configuration stated by each cited paper**.

## Decision Transformer

The referenced IEEE Access paper's Appendix A reports a sequence length of 20, state/RTG
embedding dimension 128, 3 Transformer encoder layers, 4 attention heads, dropout 0.3,
AdamW at 1e-4, weight decay 1e-5, batch size 32, and 150 epochs. Its preprocessing section
also reports Savitzky-Golay filtering and dropping sensors 1, 5, 10, 16, 18, and 19.

The supplied C3M-Farm manuscript instead states that the controlled rerun used context length
128, hidden dimension 128, 6 layers, 8 heads, and AdamW at 1e-4.

Both are implemented:

- `decision_transformer_paper.yaml`
- `decision_transformer_controlled.yaml`

Do not describe the controlled variant as the cited paper's exact Appendix-A architecture.

## Transformer-GRU

The open-access Sensors paper reports a pre-optimization model with 256 GRUs, 2 attention
heads, dropout 0.05, Adam at 1e-3, and batch 64. Its HHO-WHO optimized table reports:
learning rate 0.00094, 44 GRUs, 16 dense units, dropout 0.0, 3 attention heads, 2 GRU
layers, and 1 dense layer.

The supplied C3M-Farm manuscript states that its controlled rerun used Transformer
`d_model=128`, 4 heads, 4 layers, followed by GRU 128 with 2 layers, Adam at 1e-3,
batch 32.

Both are represented by separate configs. The published optimized table does not expose every
Transformer structural choice needed by a PyTorch implementation; the repository marks its
`d_model` and Transformer depth as explicit implementation choices.

## MACPTD

No public official source repository was found during the repository preparation, and the
publicly accessible material exposed the abstract rather than the full architecture. The abstract
supports these components:

- multi-level augmentation using amplitude/phase perturbation, temporal flipping, and sparse noise;
- periodic/trend contrastive disentanglement with invertible frequency decomposition;
- a causal convolutional attention module;
- dual-domain contrastive learning.

The supplied C3M-Farm manuscript adds Adam `1e-3`, temperature `0.1`, and batch `64`.
`macptd_controlled.yaml` is therefore a **best-supported reconstruction**, not an asserted copy
of unavailable author source code.

Publication claims should use that wording until the original MACPTD source/configuration is
obtained from its authors or supplementary material.
