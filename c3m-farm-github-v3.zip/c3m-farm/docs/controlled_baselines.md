# Controlled baseline implementation status

The repository now includes runnable implementations for the three methods used in the
manuscript's controlled comparison:

- Decision Transformer
- MACPTD
- Transformer-GRU

The original author source trees and raw paired prediction records for the manuscript reruns
were not included with the supplied manuscript. The repository therefore distinguishes:

1. the exact controlled hyperparameters stated by the manuscript;
2. architecture/hyperparameter details available from the cited publications;
3. explicit implementation choices where neither source exposes enough detail.

Decision Transformer and Transformer-GRU each have separate manuscript-controlled and
publication-oriented configs because those sources disagree on important architecture values.
MACPTD remains a best-supported reconstruction because no public official source code/full
architecture was recovered.

See `docs/baseline_sources.md` and `sources/baseline_sources.json`.

Raw predictions from new runs are written under `runs/controlled/`. These generated outputs
must not be represented as the manuscript's preserved historical predictions unless they are
independently verified against the authors' original supplementary artifacts.
