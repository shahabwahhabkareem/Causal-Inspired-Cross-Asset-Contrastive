# NASA C-MAPSS data

The Git repository intentionally does not vendor the C-MAPSS dataset.

Use:

```bash
python scripts/download_cmapss.py --output data/raw/CMaps
```

The downloader first tries the current NASA Prognostics Center of Excellence dataset URL and
then the CMAPSS archive URL used by NASA's `progpy` loader as a fallback. It recursively
extracts nested ZIP files, validates the 12 standard train/test/RUL files, computes SHA-256
hashes, and writes `SOURCE.json`.

Expected files:

```text
train_FD001.txt ... train_FD004.txt
test_FD001.txt  ... test_FD004.txt
RUL_FD001.txt   ... RUL_FD004.txt
```

The controlled C3M-Farm pipeline uses only the training trajectories and creates engine-disjoint
70/15/15 train/validation/test partitions before window generation, matching the supplied
manuscript's controlled protocol.

Run the complete matrix:

```bash
python scripts/run_controlled_matrix.py \
  --data-root data/raw/CMaps \
  --output-root runs/controlled
```

Summarize all completed seeds:

```bash
python scripts/summarize_controlled_runs.py \
  --runs-root runs/controlled \
  --metric-scope window
```
