from pathlib import Path

import torch

from c3m_farm.config import load_config
from c3m_farm.models.c3m_farm import C3MFarm

ROOT = Path(__file__).resolve().parents[1]


def test_model_forward_shapes():
    config = load_config(ROOT / "configs/reference_cmapss.yaml")
    model = C3MFarm(config)
    batch = 4
    modalities = {
        "sensor": torch.randn(batch, 128, 21),
        "spectral": torch.randn(batch, 21, 65, 3),
        "context": torch.randn(batch, 3),
        "text": torch.randint(0, 32, (batch, 16)),
    }
    engine_ids = torch.tensor([1, 2, 3, 4])
    output = model(modalities, engine_ids)
    assert output["class_logits"].shape == (batch, 3)
    assert output["rul"].shape == (batch,)
    assert output["predicted_future_health"].shape == (batch, 128)
    assert output["adjacency"].shape == (batch, batch)
