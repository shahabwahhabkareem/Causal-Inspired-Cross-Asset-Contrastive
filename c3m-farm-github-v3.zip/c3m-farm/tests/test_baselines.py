from pathlib import Path

import torch
import yaml

from c3m_farm.baseline_training import build_baseline

ROOT = Path(__file__).resolve().parents[1]


def load_config(name: str) -> dict:
    with (ROOT / "configs/baselines" / name).open("r", encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def modalities(batch: int = 3) -> dict[str, torch.Tensor]:
    return {
        "sensor": torch.randn(batch, 128, 21),
        "context": torch.randn(batch, 3),
    }


def test_controlled_decision_transformer_forward():
    model = build_baseline(load_config("decision_transformer_controlled.yaml"))
    output = model(modalities())
    assert output.rul.shape == (3,)
    assert output.auxiliary["action_logits"].shape == (3, 3)


def test_controlled_transformer_gru_forward():
    model = build_baseline(load_config("transformer_gru_controlled.yaml"))
    output = model(modalities())
    assert output.rul.shape == (3,)


def test_controlled_macptd_forward():
    model = build_baseline(load_config("macptd_controlled.yaml"))
    model.eval()
    output = model(modalities())
    assert output.rul.shape == (3,)
    assert torch.isfinite(output.auxiliary["time_contrastive"])
    assert torch.isfinite(output.auxiliary["frequency_contrastive"])
