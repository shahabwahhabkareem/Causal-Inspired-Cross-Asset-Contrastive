from pathlib import Path

from c3m_farm.audit import verify_controlled_summary, verify_preserved_results

ROOT = Path(__file__).resolve().parents[1]


def test_preserved_summary_audit():
    assert verify_preserved_results(ROOT) == []


def test_controlled_summary_audit():
    assert verify_controlled_summary(ROOT) == []
