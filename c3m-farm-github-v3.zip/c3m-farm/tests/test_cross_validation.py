import numpy as np

from c3m_farm.cross_validation import make_grouped_kfold_splits, paired_t_summary


def test_grouped_five_fold_is_disjoint_and_exhaustive():
    engines = list(range(1, 101))
    folds = make_grouped_kfold_splits(
        engines,
        n_splits=5,
        fold_seed=42,
        validation_fraction_of_total=0.15,
    )
    assert len(folds) == 5

    all_test = []
    for fold in folds:
        train, val, test = set(fold.train), set(fold.val), set(fold.test)
        assert train.isdisjoint(val)
        assert train.isdisjoint(test)
        assert val.isdisjoint(test)
        assert train | val | test == set(engines)
        all_test.extend(fold.test)

    assert sorted(all_test) == engines
    assert len(all_test) == len(set(all_test))


def test_grouped_five_fold_is_seed_deterministic():
    first = make_grouped_kfold_splits(range(1, 51), fold_seed=123)
    second = make_grouped_kfold_splits(range(1, 51), fold_seed=123)
    assert first == second


def test_paired_summary_uses_baseline_minus_c3m_direction():
    c3m = np.array([2.0, 2.1, 1.9, 2.2, 2.0])
    baseline = np.array([2.5, 2.6, 2.4, 2.7, 2.5])
    summary = paired_t_summary(c3m, baseline)
    assert summary["n"] == 5
    assert summary["mean_difference_baseline_minus_c3m"] > 0
    assert summary["p_value"] < 0.05
