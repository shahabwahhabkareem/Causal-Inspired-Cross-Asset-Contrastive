import torch

from c3m_farm.data.cmapss import LeakageSafeTextView


def test_text_view_is_deterministic_and_fixed_length():
    encoder = LeakageSafeTextView(
        max_tokens=16,
        top_k_sensors=6,
        trend_threshold=0.15,
        volatility_threshold=0.20,
    )
    window = torch.linspace(0, 1, 128).unsqueeze(1).repeat(1, 21)
    first = encoder.encode(window)
    second = encoder.encode(window)
    assert torch.equal(first, second)
    assert first.shape == (16,)
