import json

from c3m_farm.data.cmapss import EngineSplit, load_engine_split_manifest, validate_engine_split


def test_explicit_split_round_trip(tmp_path):
    path = tmp_path / "fold.json"
    path.write_text(
        json.dumps(
            {
                "train_engines": [1, 2, 3],
                "val_engines": [4],
                "test_engines": [5],
            }
        ),
        encoding="utf-8",
    )
    split = load_engine_split_manifest(path)
    assert split == EngineSplit(train=(1, 2, 3), val=(4,), test=(5,))
    validate_engine_split(split, [1, 2, 3, 4, 5])
