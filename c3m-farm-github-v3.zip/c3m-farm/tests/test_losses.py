from pathlib import Path

import torch

from c3m_farm.config import load_config
from c3m_farm.losses import compute_total_loss
from c3m_farm.models.c3m_farm import C3MFarm

ROOT = Path(__file__).resolve().parents[1]


def test_total_loss_is_finite_and_backward_works():
    config = load_config(ROOT / "configs/reference_cmapss.yaml")
    model = C3MFarm(config)
    batch_size = 3
    modalities = {
        "sensor": torch.randn(batch_size, 128, 21),
        "spectral": torch.randn(batch_size, 21, 65, 3),
        "context": torch.randn(batch_size, 3),
        "text": torch.randint(0, 32, (batch_size, 16)),
    }
    batch = {
        "fault_class": torch.tensor([0, 1, 2]),
        "rul": torch.tensor([100.0, 50.0, 10.0]),
        "future_valid": torch.tensor([True, True, False]),
    }
    output = model(modalities, torch.tensor([1, 2, 3]))
    future_health = model.encode_health(modalities)
    total, components = compute_total_loss(
        output,
        batch,
        future_health,
        config.loss_weights,
        float(config.training["contrastive_temperature"]),
    )
    assert torch.isfinite(total)
    assert set(components) == {
        "contrastive",
        "orthogonality",
        "reconstruction",
        "classification",
        "rul",
        "trajectory",
        "risk",
    }
    total.backward()
