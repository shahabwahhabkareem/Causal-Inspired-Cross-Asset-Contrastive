from pathlib import Path

import pytest

from c3m_farm.config import load_config

ROOT = Path(__file__).resolve().parents[1]


def test_reference_config_is_runnable():
    config = load_config(ROOT / "configs/reference_cmapss.yaml")
    assert config.data["window_length"] == 128
    assert config.data["stride"] == 64


def test_paper_record_refuses_unreported_details():
    with pytest.raises(ValueError):
        load_config(ROOT / "configs/paper_reported.yaml")
