from c3m_farm.data.cmapss import split_engine_ids


def test_engine_split_is_disjoint_and_complete():
    engines = list(range(1, 101))
    split = split_engine_ids(engines, 0.70, 0.15, seed=42)
    train, val, test = set(split.train), set(split.val), set(split.test)
    assert train.isdisjoint(val)
    assert train.isdisjoint(test)
    assert val.isdisjoint(test)
    assert train | val | test == set(engines)


def test_engine_split_is_seed_deterministic():
    first = split_engine_ids(range(1, 31), 0.70, 0.15, seed=123)
    second = split_engine_ids(range(1, 31), 0.70, 0.15, seed=123)
    assert first == second
