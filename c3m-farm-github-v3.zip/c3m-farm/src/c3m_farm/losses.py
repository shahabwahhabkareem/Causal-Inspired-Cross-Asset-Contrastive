"""Loss terms corresponding to the C3M-Farm manuscript objective."""

from __future__ import annotations

import itertools

import torch
from torch.nn import functional as F


def orthogonality_loss(
    latent: dict[str, dict[str, torch.Tensor]],
) -> torch.Tensor:
    losses = []
    for values in latent.values():
        health = values["health"]
        environment = values["environment"]
        cross = health.transpose(0, 1) @ environment
        losses.append(cross.pow(2).sum() / max(1, health.shape[0] ** 2))
    return torch.stack(losses).mean()


def reconstruction_loss(
    hidden: dict[str, torch.Tensor],
    latent: dict[str, dict[str, torch.Tensor]],
) -> torch.Tensor:
    losses = [
        F.mse_loss(latent[name]["reconstructed"], hidden[name])
        for name in latent
    ]
    return torch.stack(losses).mean()


def _cosine_logits(
    first: torch.Tensor,
    second: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    first = F.normalize(first, p=2, dim=-1)
    second = F.normalize(second, p=2, dim=-1)
    return first @ second.transpose(0, 1) / temperature


def cross_modal_info_nce(
    latent: dict[str, dict[str, torch.Tensor]],
    temperature: float,
) -> torch.Tensor:
    names = sorted(latent)
    if len(names) < 2:
        return next(iter(latent.values()))["health"].new_zeros(())
    labels = torch.arange(
        next(iter(latent.values()))["health"].shape[0],
        device=next(iter(latent.values()))["health"].device,
    )
    losses = []
    for first_name, second_name in itertools.combinations(names, 2):
        logits = _cosine_logits(
            latent[first_name]["health"],
            latent[second_name]["health"],
            temperature,
        )
        losses.append(F.cross_entropy(logits, labels))
    return torch.stack(losses).mean()


def trajectory_loss(
    predicted_future_health: torch.Tensor,
    target_future_health: torch.Tensor,
    valid_mask: torch.Tensor,
) -> torch.Tensor:
    valid = valid_mask.bool()
    if not torch.any(valid):
        return predicted_future_health.new_zeros(())
    return F.mse_loss(predicted_future_health[valid], target_future_health[valid])


def compute_total_loss(
    output: dict,
    batch: dict,
    future_health: torch.Tensor,
    weights: dict[str, float],
    temperature: float,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    components = {
        "contrastive": cross_modal_info_nce(output["latent"], temperature),
        "orthogonality": orthogonality_loss(output["latent"]),
        "reconstruction": reconstruction_loss(output["hidden"], output["latent"]),
        "classification": F.cross_entropy(output["class_logits"], batch["fault_class"]),
        "rul": F.mse_loss(output["rul"], batch["rul"]),
        "trajectory": trajectory_loss(
            output["predicted_future_health"],
            future_health.detach(),
            batch["future_valid"],
        ),
    }
    if weights.get("risk", 0.0) > 0:
        if "risk" not in batch:
            raise ValueError("Risk loss is enabled but no calibrated risk labels were supplied.")
        components["risk"] = F.binary_cross_entropy_with_logits(
            output["risk_logits"],
            batch["risk"].float(),
        )
    else:
        components["risk"] = output["rul"].new_zeros(())

    total = sum(float(weights[name]) * value for name, value in components.items())
    return total, components
