"""End-to-end training, early stopping, prediction persistence, and run manifests."""

from __future__ import annotations

import hashlib
import json
import random
import subprocess
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml
from torch.nn import functional as F

from .losses import compute_total_loss
from .metrics import classification_metrics, regression_metrics
from .models.c3m_farm import C3MFarm


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def move_to_device(value, device: torch.device):
    if isinstance(value, torch.Tensor):
        return value.to(device)
    if isinstance(value, dict):
        return {key: move_to_device(item, device) for key, item in value.items()}
    return value


def git_commit() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def config_digest(raw_config: dict) -> str:
    payload = yaml.safe_dump(raw_config, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


@dataclass
class EpochResult:
    loss: float
    components: dict[str, float]


class Trainer:
    """Trainer that stores first-class histories, predictions, metrics, and provenance."""

    def __init__(
        self,
        model: C3MFarm,
        config,
        device: torch.device,
        output_dir: str | Path,
    ) -> None:
        self.model = model.to(device)
        self.config = config
        self.device = device
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        training = config.training
        optimizer_name = training["optimizer"].lower()
        optimizer_class = torch.optim.AdamW if optimizer_name == "adamw" else torch.optim.Adam
        self.optimizer = optimizer_class(
            self.model.parameters(),
            lr=float(training["learning_rate"]),
            weight_decay=float(training["weight_decay"]),
        )
        amp_enabled = bool(training.get("amp", False)) and device.type == "cuda"
        self.scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
        self.amp_enabled = amp_enabled

    def _run_epoch(self, loader, training: bool) -> EpochResult:
        self.model.train(training)
        total_loss = 0.0
        component_sums: dict[str, float] = {}
        batches = 0

        for raw_batch in loader:
            batch = move_to_device(raw_batch, self.device)
            if training:
                self.optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast(device_type=self.device.type, enabled=self.amp_enabled):
                output = self.model(batch["modalities"], batch["engine_id"])
                future_health = self.model.encode_health(batch["future_modalities"])
                loss, components = compute_total_loss(
                    output=output,
                    batch=batch,
                    future_health=future_health,
                    weights=self.config.loss_weights,
                    temperature=float(self.config.training["contrastive_temperature"]),
                )

            if training:
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    float(self.config.training["gradient_clip_norm"]),
                )
                self.scaler.step(self.optimizer)
                self.scaler.update()

            total_loss += float(loss.detach().cpu())
            for name, value in components.items():
                component_sums[name] = component_sums.get(name, 0.0) + float(value.detach().cpu())
            batches += 1

        return EpochResult(
            loss=total_loss / max(1, batches),
            components={name: value / max(1, batches) for name, value in component_sums.items()},
        )

    def fit(self, train_loader, val_loader) -> pd.DataFrame:
        patience = int(self.config.training["early_stopping_patience"])
        epochs = int(self.config.training["epochs"])
        best_loss = float("inf")
        stale_epochs = 0
        history: list[dict] = []
        checkpoint_path = self.output_dir / "best_model.pt"

        for epoch in range(1, epochs + 1):
            train_result = self._run_epoch(train_loader, training=True)
            with torch.no_grad():
                val_result = self._run_epoch(val_loader, training=False)

            row = {
                "epoch": epoch,
                "train_loss": train_result.loss,
                "val_loss": val_result.loss,
            }
            row.update({f"train_{key}": value for key, value in train_result.components.items()})
            row.update({f"val_{key}": value for key, value in val_result.components.items()})
            history.append(row)

            if val_result.loss < best_loss:
                best_loss = val_result.loss
                stale_epochs = 0
                torch.save(self.model.state_dict(), checkpoint_path)
            else:
                stale_epochs += 1
                if stale_epochs >= patience:
                    break

        history_frame = pd.DataFrame(history)
        history_frame.to_csv(self.output_dir / "history.csv", index=False)
        self.model.load_state_dict(torch.load(checkpoint_path, map_location=self.device))
        return history_frame

    @torch.no_grad()
    def evaluate(self, loader) -> tuple[pd.DataFrame, dict[str, float]]:
        self.model.eval()
        rows: list[dict] = []
        probability_rows: list[np.ndarray] = []

        for raw_batch in loader:
            batch = move_to_device(raw_batch, self.device)
            output = self.model(batch["modalities"], batch["engine_id"])
            probabilities = F.softmax(output["class_logits"], dim=-1)
            predictions = probabilities.argmax(dim=-1)

            for index in range(batch["rul"].shape[0]):
                rows.append(
                    {
                        "engine_id": int(batch["engine_id"][index].cpu()),
                        "end_cycle": int(batch["end_cycle"][index].cpu()),
                        "y_rul": float(batch["rul"][index].cpu()),
                        "pred_rul": float(output["rul"][index].cpu()),
                        "y_class": int(batch["fault_class"][index].cpu()),
                        "pred_class": int(predictions[index].cpu()),
                    }
                )
                probability_rows.append(probabilities[index].cpu().numpy())

        frame = pd.DataFrame(rows)
        probability_matrix = np.stack(probability_rows)
        for class_index in range(probability_matrix.shape[1]):
            frame[f"prob_class_{class_index}"] = probability_matrix[:, class_index]

        reg = regression_metrics(frame["y_rul"].to_numpy(), frame["pred_rul"].to_numpy())
        cls = classification_metrics(
            frame["y_class"].to_numpy(),
            frame["pred_class"].to_numpy(),
            probability_matrix,
        )
        final_frame = (
            frame.sort_values(["engine_id", "end_cycle"])
            .groupby("engine_id", as_index=False)
            .tail(1)
            .reset_index(drop=True)
        )
        final_reg = regression_metrics(
            final_frame["y_rul"].to_numpy(),
            final_frame["pred_rul"].to_numpy(),
        )
        metrics = {
            **reg,
            **cls,
            "final_window_per_engine": final_reg,
            "n_windows": int(len(frame)),
            "n_engines": int(final_frame["engine_id"].nunique()),
        }
        frame.to_csv(self.output_dir / "predictions.csv", index=False)
        final_frame.to_csv(self.output_dir / "final_window_predictions.csv", index=False)
        with (self.output_dir / "metrics.json").open("w", encoding="utf-8") as stream:
            json.dump(metrics, stream, indent=2, allow_nan=True)
        return frame, metrics

    def write_run_manifest(
        self,
        subset: str,
        seed: int,
        split_manifest: dict,
    ) -> None:
        manifest = {
            "model": "c3m_farm",
            "subset": subset,
            "seed": seed,
            "config_sha256": config_digest(self.config.raw),
            "git_commit": git_commit(),
            "torch_version": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
            "device": str(self.device),
            "split": split_manifest,
        }
        with (self.output_dir / "run_manifest.json").open("w", encoding="utf-8") as stream:
            json.dump(manifest, stream, indent=2)
        with (self.output_dir / "config_resolved.yaml").open("w", encoding="utf-8") as stream:
            yaml.safe_dump(self.config.raw, stream, sort_keys=False)
