"""CLI for the controlled baseline implementations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from .baseline_training import (
    BaselineTrainer,
    build_baseline,
    load_baseline_config,
    set_seed,
)
from .config import load_config
from .data.cmapss import CMapssDataModule, load_engine_split_manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one controlled C-MAPSS baseline.")
    parser.add_argument("--baseline-config", required=True)
    parser.add_argument("--shared-config", default="configs/reference_cmapss.yaml")
    parser.add_argument("--subset", choices=["FD001", "FD002", "FD003", "FD004"], required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--output-root", default="runs/baselines")
    parser.add_argument("--split-manifest", default=None)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    baseline_config = load_baseline_config(args.baseline_config)
    shared_config = load_config(args.shared_config)
    set_seed(args.seed)
    device = torch.device(
        args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu")
    )

    split_override = (
        load_engine_split_manifest(args.split_manifest)
        if args.split_manifest
        else None
    )
    data = CMapssDataModule(
        data_root=args.data_root,
        subset=args.subset,
        seed=args.seed,
        config=shared_config,
        split_override=split_override,
    )
    data.setup()
    train_loader, val_loader, test_loader = data.loaders(
        batch_size=int(baseline_config["training"]["batch_size"])
    )

    output_dir = (
        Path(args.output_root)
        / baseline_config["name"]
        / baseline_config["variant"]
        / args.subset
        / f"seed_{args.seed}"
    )
    model = build_baseline(baseline_config)
    trainer = BaselineTrainer(model, baseline_config, device, output_dir)
    trainer.fit(train_loader, val_loader)
    _, metrics = trainer.evaluate(test_loader)
    trainer.write_metadata(args.subset, args.seed, data.split_manifest())

    print(json.dumps(metrics, indent=2))
    print(f"Artifacts: {output_dir}")


if __name__ == "__main__":
    main()
