"""Shared baseline utilities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torch import nn


@dataclass
class BaselineOutput:
    """Standard output contract for controlled RUL baselines."""

    rul: torch.Tensor
    auxiliary: dict[str, torch.Tensor]


class RULBaseline(nn.Module):
    """Base class for controlled RUL baselines."""

    def compute_loss(self, output: BaselineOutput, batch: dict[str, Any]) -> torch.Tensor:
        raise NotImplementedError
