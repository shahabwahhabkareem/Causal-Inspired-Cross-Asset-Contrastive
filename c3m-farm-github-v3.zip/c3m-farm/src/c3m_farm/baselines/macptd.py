"""Best-supported MACPTD reconstruction from public descriptions and manuscript settings."""

from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F

from .common import BaselineOutput, RULBaseline


def _info_nce(first: torch.Tensor, second: torch.Tensor, temperature: float) -> torch.Tensor:
    first = F.normalize(first, dim=-1)
    second = F.normalize(second, dim=-1)
    logits = first @ second.transpose(0, 1) / temperature
    labels = torch.arange(first.shape[0], device=first.device)
    return 0.5 * (
        F.cross_entropy(logits, labels)
        + F.cross_entropy(logits.transpose(0, 1), labels)
    )


class MultiLevelAugmentation(nn.Module):
    """Amplitude/phase perturbation, temporal flipping, and sparse-noise injection."""

    def __init__(
        self,
        amplitude_std: float,
        phase_std: float,
        sparse_noise_probability: float,
        sparse_noise_std: float,
        flip_probability: float,
    ) -> None:
        super().__init__()
        self.amplitude_std = amplitude_std
        self.phase_std = phase_std
        self.sparse_noise_probability = sparse_noise_probability
        self.sparse_noise_std = sparse_noise_std
        self.flip_probability = flip_probability

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        if not self.training:
            return values

        spectrum = torch.fft.rfft(values, dim=1)
        amplitude_scale = 1.0 + torch.randn_like(spectrum.real) * self.amplitude_std
        phase_shift = torch.randn_like(spectrum.real) * self.phase_std
        rotated = spectrum * amplitude_scale * torch.exp(1j * phase_shift)
        augmented = torch.fft.irfft(rotated, n=values.shape[1], dim=1)

        if torch.rand((), device=values.device) < self.flip_probability:
            augmented = torch.flip(augmented, dims=(1,))

        sparse_mask = (
            torch.rand_like(augmented) < self.sparse_noise_probability
        ).to(augmented.dtype)
        noise = torch.randn_like(augmented) * self.sparse_noise_std
        return augmented + sparse_mask * noise


class InvertibleFrequencyDisentangler(nn.Module):
    """Frequency gate whose trend and periodic outputs reconstruct the input exactly."""

    def __init__(self, sequence_length: int, channels: int) -> None:
        super().__init__()
        frequencies = sequence_length // 2 + 1
        initial = torch.linspace(2.0, -2.0, frequencies).view(1, frequencies, 1)
        self.frequency_logits = nn.Parameter(initial.expand(1, frequencies, channels).clone())

    def forward(self, values: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        spectrum = torch.fft.rfft(values, dim=1)
        trend_gate = torch.sigmoid(self.frequency_logits)
        trend_spectrum = spectrum * trend_gate
        periodic_spectrum = spectrum * (1.0 - trend_gate)
        trend = torch.fft.irfft(trend_spectrum, n=values.shape[1], dim=1)
        periodic = torch.fft.irfft(periodic_spectrum, n=values.shape[1], dim=1)
        return trend, periodic


class CausalConvAttention(nn.Module):
    """Causal convolutional feature extractor with channel attention."""

    def __init__(self, input_dim: int, hidden_dim: int, kernel_size: int) -> None:
        super().__init__()
        self.kernel_size = kernel_size
        self.conv = nn.Conv1d(input_dim, hidden_dim, kernel_size=kernel_size)
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Sigmoid(),
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        transposed = values.transpose(1, 2)
        padded = F.pad(transposed, (self.kernel_size - 1, 0))
        features = F.gelu(self.conv(padded)).transpose(1, 2)
        pooled = features.mean(dim=1)
        return pooled * self.gate(pooled)


class MACPTD(RULBaseline):
    """Periodic/trend disentanglement + CCAM + dual-domain contrastive RUL model."""

    def __init__(self, config: dict) -> None:
        super().__init__()
        model = config["model"]
        augmentation = config["augmentation"]
        self.temperature = float(config["training"]["temperature"])
        self.contrastive_weight = float(config["training"].get("contrastive_weight", 0.1))
        self.sequence_length = int(model["sequence_length"])
        channels = int(model.get("input_channels", 24))
        hidden_dim = int(model["hidden_dim"])

        self.augmentation = MultiLevelAugmentation(
            amplitude_std=float(augmentation["amplitude_std"]),
            phase_std=float(augmentation["phase_std"]),
            sparse_noise_probability=float(augmentation["sparse_noise_probability"]),
            sparse_noise_std=float(augmentation["sparse_noise_std"]),
            flip_probability=float(augmentation["flip_probability"]),
        )
        self.disentangler = InvertibleFrequencyDisentangler(
            sequence_length=self.sequence_length,
            channels=channels,
        )
        self.trend_encoder = CausalConvAttention(
            input_dim=channels,
            hidden_dim=hidden_dim,
            kernel_size=int(model["kernel_size"]),
        )
        self.periodic_encoder = CausalConvAttention(
            input_dim=channels,
            hidden_dim=hidden_dim,
            kernel_size=int(model["kernel_size"]),
        )
        self.frequency_projection = nn.Sequential(
            nn.Linear(channels, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.regressor = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(float(model["dropout"])),
            nn.Linear(hidden_dim, 1),
        )

    def _state(self, modalities: dict[str, torch.Tensor]) -> torch.Tensor:
        sensor = modalities["sensor"][:, -self.sequence_length :]
        context = modalities["context"].unsqueeze(1).expand(-1, sensor.shape[1], -1)
        return torch.cat([context, sensor], dim=-1)

    def _encode(self, state: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        trend, periodic = self.disentangler(state)
        trend_embedding = self.trend_encoder(trend)
        periodic_embedding = self.periodic_encoder(periodic)
        spectrum = torch.fft.rfft(state, dim=1).abs().mean(dim=1)
        frequency_embedding = self.frequency_projection(spectrum)
        return trend_embedding, periodic_embedding, frequency_embedding

    def forward(self, modalities: dict[str, torch.Tensor]) -> BaselineOutput:
        state = self._state(modalities)
        augmented = self.augmentation(state)

        trend, periodic, frequency = self._encode(state)
        aug_trend, aug_periodic, aug_frequency = self._encode(augmented)
        rul = self.regressor(torch.cat([trend, periodic], dim=-1)).squeeze(-1)

        time_contrastive = 0.5 * (
            _info_nce(trend, aug_trend, self.temperature)
            + _info_nce(periodic, aug_periodic, self.temperature)
        )
        frequency_contrastive = _info_nce(frequency, aug_frequency, self.temperature)
        return BaselineOutput(
            rul=rul,
            auxiliary={
                "time_contrastive": time_contrastive,
                "frequency_contrastive": frequency_contrastive,
            },
        )

    def compute_loss(self, output: BaselineOutput, batch: dict) -> torch.Tensor:
        regression = F.mse_loss(output.rul, batch["rul"])
        contrastive = (
            output.auxiliary["time_contrastive"]
            + output.auxiliary["frequency_contrastive"]
        )
        return regression + self.contrastive_weight * contrastive
