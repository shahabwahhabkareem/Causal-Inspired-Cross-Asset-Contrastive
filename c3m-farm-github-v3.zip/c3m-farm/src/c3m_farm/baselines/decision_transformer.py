"""Decision Transformer reproduction for C-MAPSS RUL prediction."""

from __future__ import annotations

import torch
from scipy.signal import savgol_coeffs
from torch import nn
from torch.nn import functional as F

from .common import BaselineOutput, RULBaseline


class SavitzkyGolayFilter(nn.Module):
    """Fixed Savitzky-Golay smoothing applied independently to each feature."""

    def __init__(self, window_length: int = 7, polynomial_order: int = 2) -> None:
        super().__init__()
        coefficients = savgol_coeffs(window_length, polynomial_order, use="conv")
        kernel = torch.tensor(coefficients, dtype=torch.float32).view(1, 1, -1)
        self.register_buffer("kernel", kernel)
        self.padding = window_length // 2

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        features = values.shape[-1]
        transposed = values.transpose(1, 2)
        kernel = self.kernel.expand(features, 1, -1)
        padded = F.pad(transposed, (self.padding, self.padding), mode="replicate")
        smoothed = F.conv1d(padded, kernel, groups=features)
        return smoothed.transpose(1, 2)


class DecisionTransformerRUL(RULBaseline):
    """Supervised Decision-Transformer adaptation with RUL and urgency heads."""

    PAPER_DROPPED_SENSOR_INDICES = (0, 4, 9, 15, 17, 18)

    def __init__(self, config: dict) -> None:
        super().__init__()
        model = config["model"]
        preprocessing = config.get("preprocessing", {})
        self.sequence_length = int(model["sequence_length"])
        self.use_paper_sensor_selection = bool(
            preprocessing.get("drop_paper_uninformative_sensors", False)
        )
        self.use_savgol = bool(preprocessing.get("savgol", False))

        sensor_count = 21 - (
            len(self.PAPER_DROPPED_SENSOR_INDICES) if self.use_paper_sensor_selection else 0
        )
        input_dim = sensor_count + 3
        d_model = int(model["d_model"])
        heads = int(model["attention_heads"])
        layers = int(model["transformer_layers"])
        dropout = float(model["dropout"])

        if d_model % heads != 0:
            raise ValueError("d_model must be divisible by attention_heads.")

        self.smoother = SavitzkyGolayFilter(
            int(preprocessing.get("savgol_window", 7)),
            int(preprocessing.get("savgol_polyorder", 2)),
        )
        self.state_embedding = nn.Linear(input_dim, d_model)
        self.position_embedding = nn.Parameter(
            torch.zeros(1, self.sequence_length, d_model)
        )

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=heads,
            dim_feedforward=int(model.get("feedforward_dim", d_model * 4)),
            dropout=dropout,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=layers)
        self.temporal_attention = nn.MultiheadAttention(
            embed_dim=d_model,
            num_heads=heads,
            dropout=dropout,
            batch_first=True,
        )
        self.temporal_norm = nn.LayerNorm(d_model)
        self.rul_head = nn.Linear(d_model, 1)
        self.action_head = nn.Linear(d_model, 3)

        nn.init.normal_(self.position_embedding, std=0.02)

    def _prepare_state(self, modalities: dict[str, torch.Tensor]) -> torch.Tensor:
        sensor = modalities["sensor"]
        context = modalities["context"]

        sensor = sensor[:, -self.sequence_length :]
        if self.use_paper_sensor_selection:
            keep = [
                index
                for index in range(sensor.shape[-1])
                if index not in self.PAPER_DROPPED_SENSOR_INDICES
            ]
            sensor = sensor[..., keep]
        if self.use_savgol:
            sensor = self.smoother(sensor)

        context = context.unsqueeze(1).expand(-1, sensor.shape[1], -1)
        return torch.cat([context, sensor], dim=-1)

    def forward(self, modalities: dict[str, torch.Tensor]) -> BaselineOutput:
        state = self._prepare_state(modalities)
        length = state.shape[1]
        hidden = self.state_embedding(state) + self.position_embedding[:, :length]
        hidden = self.encoder(hidden)

        attended, _ = self.temporal_attention(hidden, hidden, hidden, need_weights=False)
        hidden = self.temporal_norm(hidden + attended)
        final = hidden[:, -1]
        return BaselineOutput(
            rul=self.rul_head(final).squeeze(-1),
            auxiliary={"action_logits": self.action_head(final)},
        )

    def compute_loss(self, output: BaselineOutput, batch: dict) -> torch.Tensor:
        rul_loss = F.l1_loss(output.rul, batch["rul"])
        rul = batch["rul"]
        action_target = torch.where(
            rul <= 30,
            torch.full_like(rul, 2, dtype=torch.long),
            torch.where(
                rul <= 60,
                torch.ones_like(rul, dtype=torch.long),
                torch.zeros_like(rul, dtype=torch.long),
            ),
        )
        action_loss = F.cross_entropy(output.auxiliary["action_logits"], action_target)
        return rul_loss + float(0.1) * action_loss
