"""Transformer-GRU reproductions for C-MAPSS RUL prediction."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F

from .common import BaselineOutput, RULBaseline


class TransformerGRU(RULBaseline):
    """Transformer encoder followed by GRU sequence modeling and dense regression."""

    def __init__(self, config: dict) -> None:
        super().__init__()
        model = config["model"]
        input_dim = int(model.get("input_dim", 24))
        d_model = int(model["d_model"])
        heads = int(model["attention_heads"])
        transformer_layers = int(model["transformer_layers"])
        gru_units = int(model["gru_units"])
        gru_layers = int(model["gru_layers"])
        dense_units = int(model["dense_units"])
        dense_layers = int(model["dense_layers"])
        dropout = float(model["dropout"])

        if d_model % heads != 0:
            raise ValueError("d_model must be divisible by attention_heads.")

        self.input_projection = nn.Linear(input_dim, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=heads,
            dim_feedforward=int(model.get("feedforward_dim", d_model * 4)),
            dropout=dropout,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=transformer_layers,
        )
        self.gru = nn.GRU(
            input_size=d_model,
            hidden_size=gru_units,
            num_layers=gru_layers,
            dropout=dropout if gru_layers > 1 else 0.0,
            batch_first=True,
        )

        layers: list[nn.Module] = []
        current = gru_units
        for _ in range(dense_layers):
            layers.extend([nn.Linear(current, dense_units), nn.ReLU()])
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            current = dense_units
        layers.append(nn.Linear(current, 1))
        self.regressor = nn.Sequential(*layers)

    def forward(self, modalities: dict[str, torch.Tensor]) -> BaselineOutput:
        sensor = modalities["sensor"]
        context = modalities["context"].unsqueeze(1).expand(-1, sensor.shape[1], -1)
        state = torch.cat([context, sensor], dim=-1)
        hidden = self.input_projection(state)
        hidden = self.transformer(hidden)
        _, final_hidden = self.gru(hidden)
        final = final_hidden[-1]
        return BaselineOutput(rul=self.regressor(final).squeeze(-1), auxiliary={})

    def compute_loss(self, output: BaselineOutput, batch: dict) -> torch.Tensor:
        return F.l1_loss(output.rul, batch["rul"])
