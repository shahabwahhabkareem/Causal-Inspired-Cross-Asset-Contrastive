"""Training and evaluation for controlled baseline models."""

from __future__ import annotations

import json
import math
import random
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import yaml
from torch.nn.utils import clip_grad_norm_

from .baselines import DecisionTransformerRUL, MACPTD, TransformerGRU
from .metrics import regression_metrics


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_baseline_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def build_baseline(config: dict[str, Any]) -> torch.nn.Module:
    name = config["name"]
    if name == "decision_transformer":
        return DecisionTransformerRUL(config)
    if name == "macptd":
        return MACPTD(config)
    if name == "transformer_gru":
        return TransformerGRU(config)
    raise ValueError(f"Unsupported baseline: {name}")


def move(value: Any, device: torch.device) -> Any:
    if isinstance(value, torch.Tensor):
        return value.to(device)
    if isinstance(value, dict):
        return {key: move(item, device) for key, item in value.items()}
    return value


class BaselineTrainer:
    """Early-stopping trainer that persists predictions and both window/final-window metrics."""

    def __init__(
        self,
        model: torch.nn.Module,
        config: dict[str, Any],
        device: torch.device,
        output_dir: str | Path,
    ) -> None:
        self.model = model.to(device)
        self.config = config
        self.device = device
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        training = config["training"]
        optimizer_name = str(training["optimizer"]).lower()
        optimizer_cls = torch.optim.AdamW if optimizer_name == "adamw" else torch.optim.Adam
        self.optimizer = optimizer_cls(
            self.model.parameters(),
            lr=float(training["learning_rate"]),
            weight_decay=float(training.get("weight_decay", 0.0)),
        )
        self.scheduler = None
        if training.get("scheduler") == "cosine":
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=int(training["epochs"]),
            )

    def _epoch(self, loader, training: bool) -> float:
        self.model.train(training)
        total = 0.0
        batches = 0
        for raw_batch in loader:
            batch = move(raw_batch, self.device)
            if training:
                self.optimizer.zero_grad(set_to_none=True)
            with torch.set_grad_enabled(training):
                output = self.model(batch["modalities"])
                loss = self.model.compute_loss(output, batch)
                if training:
                    loss.backward()
                    clip_grad_norm_(
                        self.model.parameters(),
                        float(self.config["training"].get("gradient_clip_norm", 5.0)),
                    )
                    self.optimizer.step()
            total += float(loss.detach().cpu())
            batches += 1
        if training and self.scheduler is not None:
            self.scheduler.step()
        return total / max(1, batches)

    def fit(self, train_loader, val_loader) -> pd.DataFrame:
        epochs = int(self.config["training"]["epochs"])
        patience = int(self.config["training"].get("early_stopping_patience", 12))
        best_loss = math.inf
        stale = 0
        history: list[dict[str, float]] = []
        checkpoint = self.output_dir / "best_model.pt"

        for epoch in range(1, epochs + 1):
            train_loss = self._epoch(train_loader, training=True)
            val_loss = self._epoch(val_loader, training=False)
            history.append(
                {
                    "epoch": epoch,
                    "train_loss": train_loss,
                    "val_loss": val_loss,
                    "learning_rate": self.optimizer.param_groups[0]["lr"],
                }
            )
            if val_loss < best_loss:
                best_loss = val_loss
                stale = 0
                torch.save(self.model.state_dict(), checkpoint)
            else:
                stale += 1
                if stale >= patience:
                    break

        frame = pd.DataFrame(history)
        frame.to_csv(self.output_dir / "history.csv", index=False)
        self.model.load_state_dict(torch.load(checkpoint, map_location=self.device))
        return frame

    @torch.no_grad()
    def evaluate(self, loader) -> tuple[pd.DataFrame, dict[str, Any]]:
        self.model.eval()
        rows: list[dict[str, float | int]] = []
        for raw_batch in loader:
            batch = move(raw_batch, self.device)
            output = self.model(batch["modalities"])
            for index in range(batch["rul"].shape[0]):
                rows.append(
                    {
                        "engine_id": int(batch["engine_id"][index].cpu()),
                        "end_cycle": int(batch["end_cycle"][index].cpu()),
                        "y_rul": float(batch["rul"][index].cpu()),
                        "pred_rul": float(output.rul[index].cpu()),
                    }
                )

        predictions = pd.DataFrame(rows).sort_values(["engine_id", "end_cycle"])
        final_predictions = predictions.groupby("engine_id", as_index=False).tail(1)

        metrics = {
            "window": regression_metrics(
                predictions["y_rul"].to_numpy(),
                predictions["pred_rul"].to_numpy(),
            ),
            "final_window_per_engine": regression_metrics(
                final_predictions["y_rul"].to_numpy(),
                final_predictions["pred_rul"].to_numpy(),
            ),
            "n_windows": int(len(predictions)),
            "n_engines": int(final_predictions["engine_id"].nunique()),
        }
        predictions.to_csv(self.output_dir / "predictions.csv", index=False)
        final_predictions.to_csv(self.output_dir / "final_window_predictions.csv", index=False)
        with (self.output_dir / "metrics.json").open("w", encoding="utf-8") as stream:
            json.dump(metrics, stream, indent=2)
        return predictions, metrics

    def write_metadata(
        self,
        subset: str,
        seed: int,
        split_manifest: dict[str, Any],
    ) -> None:
        with (self.output_dir / "baseline_config.yaml").open("w", encoding="utf-8") as stream:
            yaml.safe_dump(self.config, stream, sort_keys=False)
        metadata = {
            "baseline": self.config["name"],
            "variant": self.config["variant"],
            "source_status": self.config["source_status"],
            "subset": subset,
            "seed": seed,
            "split": split_manifest,
            "torch_version": torch.__version__,
            "device": str(self.device),
        }
        with (self.output_dir / "run_manifest.json").open("w", encoding="utf-8") as stream:
            json.dump(metadata, stream, indent=2)
