"""Engine-grouped cross-validation and paired statistical testing utilities."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import json
import math

import numpy as np
import pandas as pd
from scipy import stats

from .data.cmapss import EngineSplit


@dataclass(frozen=True)
class GroupedFold:
    """One engine-disjoint train/validation/test fold."""

    fold: int
    train: tuple[int, ...]
    val: tuple[int, ...]
    test: tuple[int, ...]


def _validate_unique_partitions(split: EngineSplit) -> None:
    train = set(split.train)
    val = set(split.val)
    test = set(split.test)
    if not train or not val or not test:
        raise ValueError("Train, validation, and test engine sets must all be non-empty.")
    if not train.isdisjoint(val) or not train.isdisjoint(test) or not val.isdisjoint(test):
        raise ValueError("Engine partitions must be mutually disjoint.")


def make_grouped_kfold_splits(
    engine_ids: list[int] | np.ndarray,
    n_splits: int = 5,
    fold_seed: int = 42,
    validation_fraction_of_total: float = 0.15,
) -> list[GroupedFold]:
    """Create exhaustive grouped K-fold test partitions with train-only inner validation.

    Classical 5-fold CV implies a 20% held-out test fold. Therefore it cannot simultaneously
    preserve the manuscript's separate 70/15/15 holdout proportions. This function records
    that distinction explicitly and targets the manuscript's n=5 grouped statistical protocol.
    """
    unique = np.array(sorted({int(value) for value in engine_ids}), dtype=int)
    if n_splits < 2:
        raise ValueError("n_splits must be at least 2.")
    if len(unique) < n_splits + 2:
        raise ValueError("Not enough engines for grouped K-fold plus validation.")

    rng = np.random.default_rng(fold_seed)
    shuffled = unique.copy()
    rng.shuffle(shuffled)
    test_groups = [np.sort(group) for group in np.array_split(shuffled, n_splits)]

    folds: list[GroupedFold] = []
    for fold_index, test_ids in enumerate(test_groups, start=1):
        remaining = np.array(
            sorted(set(unique.tolist()) - set(test_ids.tolist())),
            dtype=int,
        )
        inner_rng = np.random.default_rng(fold_seed + 10_000 + fold_index)
        inner = remaining.copy()
        inner_rng.shuffle(inner)

        target_val_count = max(1, int(round(len(unique) * validation_fraction_of_total)))
        target_val_count = min(target_val_count, len(inner) - 1)
        val_ids = np.sort(inner[:target_val_count])
        train_ids = np.sort(inner[target_val_count:])

        split = EngineSplit(
            train=tuple(int(value) for value in train_ids),
            val=tuple(int(value) for value in val_ids),
            test=tuple(int(value) for value in test_ids),
        )
        _validate_unique_partitions(split)
        folds.append(
            GroupedFold(
                fold=fold_index,
                train=split.train,
                val=split.val,
                test=split.test,
            )
        )

    observed_test = [engine for fold in folds for engine in fold.test]
    if sorted(observed_test) != sorted(unique.tolist()):
        raise RuntimeError("Grouped K-fold construction must test each engine exactly once.")
    return folds


def make_repeated_grouped_holdout_splits(
    engine_ids: list[int] | np.ndarray,
    repeats: int = 5,
    base_seed: int = 42,
    train_fraction: float = 0.70,
    val_fraction: float = 0.15,
) -> list[GroupedFold]:
    """Create five grouped 70/15/15 holdouts when exact holdout proportions are required."""
    from .data.cmapss import split_engine_ids

    folds: list[GroupedFold] = []
    for index in range(repeats):
        split = split_engine_ids(
            engine_ids,
            train_fraction=train_fraction,
            val_fraction=val_fraction,
            seed=base_seed + index,
        )
        _validate_unique_partitions(split)
        folds.append(
            GroupedFold(
                fold=index + 1,
                train=split.train,
                val=split.val,
                test=split.test,
            )
        )
    return folds


def save_folds(
    folds: list[GroupedFold],
    path: str | Path,
    *,
    protocol: str,
    subset: str,
    fold_seed: int,
) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "protocol": protocol,
        "subset": subset,
        "fold_seed": fold_seed,
        "folds": [asdict(fold) for fold in folds],
    }
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def save_single_split(
    fold: GroupedFold,
    path: str | Path,
    *,
    protocol: str,
    subset: str,
    fold_seed: int,
) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "protocol": protocol,
        "subset": subset,
        "fold_seed": fold_seed,
        "fold": fold.fold,
        "train_engines": list(fold.train),
        "val_engines": list(fold.val),
        "test_engines": list(fold.test),
    }
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_final_engine_predictions(path: str | Path) -> pd.DataFrame:
    """Load one final-window RUL prediction per held-out engine."""
    frame = pd.read_csv(path)
    required = {"engine_id", "end_cycle", "y_rul", "pred_rul"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"{path} is missing columns: {sorted(missing)}")
    frame = frame.sort_values(["engine_id", "end_cycle"])
    return frame.groupby("engine_id", as_index=False).tail(1).reset_index(drop=True)


def paired_t_summary(first: np.ndarray, second: np.ndarray) -> dict[str, float]:
    """Paired two-sided t-test with mean difference, 95% CI, and Cohen's dz."""
    if first.shape != second.shape:
        raise ValueError("Paired samples must have identical shapes.")
    if first.ndim != 1 or len(first) < 2:
        raise ValueError("Paired samples must be one-dimensional with n >= 2.")

    differences = second - first
    mean_difference = float(differences.mean())
    sd_difference = float(differences.std(ddof=1))
    sem = sd_difference / math.sqrt(len(differences))

    if sd_difference == 0.0:
        statistic = math.inf if mean_difference != 0.0 else 0.0
        p_value = 0.0 if mean_difference != 0.0 else 1.0
        lower = upper = mean_difference
        cohen_dz = math.inf if mean_difference != 0.0 else 0.0
    else:
        result = stats.ttest_rel(second, first, nan_policy="raise")
        statistic = float(result.statistic)
        p_value = float(result.pvalue)
        critical = float(stats.t.ppf(0.975, df=len(differences) - 1))
        lower = mean_difference - critical * sem
        upper = mean_difference + critical * sem
        cohen_dz = mean_difference / sd_difference

    return {
        "n": int(len(differences)),
        "mean_difference_baseline_minus_c3m": mean_difference,
        "ci95_lower": float(lower),
        "ci95_upper": float(upper),
        "t_statistic": statistic,
        "p_value": p_value,
        "cohen_dz": float(cohen_dz),
    }


def p_value_label(p_value: float) -> str:
    if p_value < 0.01:
        return "p < 0.01"
    if p_value < 0.05:
        return "p < 0.05"
    return "n.s."
