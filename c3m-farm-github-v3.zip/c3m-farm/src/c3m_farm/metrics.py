"""Evaluation metrics and paired statistical testing."""

from __future__ import annotations

import math

import numpy as np
from scipy.stats import ttest_rel
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    recall_score,
    roc_auc_score,
)


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(math.sqrt(mean_squared_error(y_true, y_pred))),
    }


def classification_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    probabilities: np.ndarray,
) -> dict[str, float]:
    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, average="weighted", zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, average="weighted", zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
    }
    try:
        metrics["auc"] = float(
            roc_auc_score(y_true, probabilities, multi_class="ovr", average="weighted")
        )
    except ValueError:
        metrics["auc"] = float("nan")
    return metrics


def paired_t_test(first: np.ndarray, second: np.ndarray) -> dict[str, float]:
    if first.shape != second.shape:
        raise ValueError("Paired samples must have identical shapes.")
    statistic, p_value = ttest_rel(first, second)
    return {"t_statistic": float(statistic), "p_value": float(p_value)}
