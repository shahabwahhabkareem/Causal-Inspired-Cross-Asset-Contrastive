"""Programmatic numerical audit for manuscript-supported summary artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def verify_preserved_results(root: Path = ROOT) -> list[str]:
    preserved = load_json(root / "artifacts/preserved/preliminary_results.json")
    headline = preserved["headline_2000"]
    expected = {
        "accuracy": 96.0,
        "precision": 95.7,
        "recall": 95.2,
        "f1": 95.4,
        "auc": 97.0,
        "rul_mae": 3.82,
        "rul_rmse": 5.24,
    }

    errors: list[str] = []
    for key, expected_value in expected.items():
        if headline[key] != expected_value:
            errors.append(f"headline.{key}: {headline[key]} != {expected_value}")

    repeated_rows = [
        preserved["training_sizes"]["2000"],
        preserved["baseline_table"]["C3M-Farm"],
        preserved["ablation_table"]["Full C3M-Farm"],
    ]
    for index, row in enumerate(repeated_rows):
        for key, expected_value in expected.items():
            if row[key] != expected_value:
                errors.append(f"repeated_row[{index}].{key}: {row[key]} != {expected_value}")

    folds = preserved["cross_validation"]
    metric_keys = ["accuracy", "precision", "recall", "f1", "auc"]
    manuscript_summary = preserved["cross_validation_summary"]
    for key in metric_keys:
        values = np.array([fold[key] for fold in folds], dtype=float)
        mean = float(values.mean())
        sd = float(values.std(ddof=1))
        if round(mean, 1) != manuscript_summary[key]["mean"]:
            errors.append(f"cross_validation.{key}.mean mismatch")
        if round(sd, 1) != manuscript_summary[key]["sd"]:
            errors.append(f"cross_validation.{key}.sd mismatch")

    return errors


def verify_controlled_summary(root: Path = ROOT) -> list[str]:
    controlled = load_json(root / "artifacts/controlled/controlled_summary.json")
    expected = {
        "FD001": [2.94, 0.12],
        "FD002": [2.11, 0.08],
        "FD003": [2.34, 0.09],
        "FD004": [2.94, 0.11],
    }
    errors: list[str] = []
    for subset, pair in expected.items():
        actual = controlled["table8"]["C3M-Farm"][subset]
        if actual != {"mean": pair[0], "sd": pair[1]}:
            errors.append(f"controlled C3M-Farm {subset}: {actual} != {pair}")
    return errors


def main() -> None:
    errors = [*verify_preserved_results(), *verify_controlled_summary()]
    if errors:
        raise SystemExit("\n".join(errors))
    print("C3M-Farm numerical summary audit passed.")
