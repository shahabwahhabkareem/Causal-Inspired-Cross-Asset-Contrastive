"""Configuration loading and validation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class ExperimentConfig:
    raw: dict[str, Any]

    @property
    def data(self) -> dict[str, Any]:
        return self.raw["data"]

    @property
    def proxy_views(self) -> dict[str, Any]:
        return self.raw["proxy_views"]

    @property
    def model(self) -> dict[str, Any]:
        return self.raw["model"]

    @property
    def training(self) -> dict[str, Any]:
        return self.raw["training"]

    @property
    def loss_weights(self) -> dict[str, float]:
        return self.raw["loss_weights"]

    def validate_runnable(self) -> None:
        required = {
            "data.window_length": self.data.get("window_length"),
            "data.stride": self.data.get("stride"),
            "data.rul_cap": self.data.get("rul_cap"),
            "data.class_thresholds": self.data.get("class_thresholds"),
            "proxy_views.stft.win_length": self.proxy_views["stft"].get("win_length"),
            "proxy_views.stft.hop_length": self.proxy_views["stft"].get("hop_length"),
            "proxy_views.stft.n_fft": self.proxy_views["stft"].get("n_fft"),
            "model.graph_layers": self.model.get("graph_layers"),
            "training.random_seeds": self.training.get("random_seeds"),
        }
        missing = [name for name, value in required.items() if value is None]
        if missing:
            joined = ", ".join(missing)
            raise ValueError(
                "Configuration is a provenance record and is not runnable. "
                f"Missing explicit values: {joined}"
            )


def load_config(path: str | Path, require_runnable: bool = True) -> ExperimentConfig:
    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as stream:
        raw = yaml.safe_load(stream)
    config = ExperimentConfig(raw=raw)
    if require_runnable:
        config.validate_runnable()
    return config


def save_config(config: ExperimentConfig, path: str | Path) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as stream:
        yaml.safe_dump(config.raw, stream, sort_keys=False)
