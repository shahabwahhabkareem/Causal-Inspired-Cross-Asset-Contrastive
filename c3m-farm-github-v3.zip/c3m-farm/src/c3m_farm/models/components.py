"""Disentanglement, graph reasoning, and attention fusion."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class Disentangler(nn.Module):
    """Project one encoded modality into health, context, and residual subspaces."""

    def __init__(self, hidden_dim: int, latent_dim: int, dropout: float) -> None:
        super().__init__()
        self.health = nn.Sequential(
            nn.Linear(hidden_dim, latent_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.environment = nn.Sequential(
            nn.Linear(hidden_dim, latent_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.residual = nn.Sequential(
            nn.Linear(hidden_dim, latent_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(self, hidden: torch.Tensor) -> dict[str, torch.Tensor]:
        health = self.health(hidden)
        environment = self.environment(hidden)
        residual = self.residual(hidden)
        reconstructed = self.decoder(torch.cat([health, environment, residual], dim=-1))
        return {
            "health": health,
            "environment": environment,
            "residual": residual,
            "reconstructed": reconstructed,
        }


def build_context_knn_adjacency(
    context: torch.Tensor,
    engine_ids: torch.Tensor,
    k: int,
    temperature: float,
    exclude_same_asset: bool,
) -> torch.Tensor:
    """Build a deterministic weighted proxy graph from current normalized operating context."""
    batch_size = context.shape[0]
    if batch_size == 1:
        return torch.zeros((1, 1), dtype=context.dtype, device=context.device)

    distances = torch.cdist(context, context, p=2)
    similarity = torch.exp(-distances / max(temperature, 1e-6))
    similarity.fill_diagonal_(0.0)

    if exclude_same_asset:
        same_asset = engine_ids[:, None] == engine_ids[None, :]
        similarity = similarity.masked_fill(same_asset, 0.0)

    adjacency = torch.zeros_like(similarity)
    for row in range(batch_size):
        candidates = torch.nonzero(similarity[row] > 0, as_tuple=False).flatten()
        if candidates.numel() == 0:
            continue
        count = min(k, int(candidates.numel()))
        values, local_indices = torch.topk(similarity[row, candidates], k=count)
        neighbors = candidates[local_indices]
        adjacency[row, neighbors] = values

    return torch.maximum(adjacency, adjacency.transpose(0, 1))


class GraphConvolution(nn.Module):
    """Dense GCN layer implementing normalized adjacency propagation."""

    def __init__(self, input_dim: int, output_dim: int) -> None:
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=False)

    def forward(self, nodes: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        identity = torch.eye(adjacency.shape[0], dtype=adjacency.dtype, device=adjacency.device)
        adjacency_tilde = adjacency + identity
        degree = adjacency_tilde.sum(dim=1).clamp_min(1e-8)
        inv_sqrt = degree.pow(-0.5)
        normalized = inv_sqrt[:, None] * adjacency_tilde * inv_sqrt[None, :]
        return normalized @ self.linear(nodes)


class GraphEncoder(nn.Module):
    """Stacked graph-convolution layers."""

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        layers: int,
        dropout: float,
    ) -> None:
        super().__init__()
        if layers < 1:
            raise ValueError("Graph encoder requires at least one layer.")
        dimensions = [input_dim, *([hidden_dim] * layers)]
        self.layers = nn.ModuleList(
            GraphConvolution(dimensions[index], dimensions[index + 1])
            for index in range(layers)
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, nodes: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        hidden = nodes
        for layer in self.layers:
            hidden = self.dropout(F.relu(layer(hidden, adjacency)))
        return hidden


class AttentionFusion(nn.Module):
    """Attention-weighted fusion over a variable number of candidate representations."""

    def __init__(self, input_dim: int) -> None:
        super().__init__()
        self.score = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.Tanh(),
            nn.Linear(input_dim, 1, bias=False),
        )

    def forward(self, candidates: list[torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        if not candidates:
            raise ValueError("At least one representation is required for fusion.")
        stacked = torch.stack(candidates, dim=1)
        scores = self.score(stacked).squeeze(-1)
        weights = torch.softmax(scores, dim=1)
        fused = torch.sum(stacked * weights.unsqueeze(-1), dim=1)
        return fused, weights
