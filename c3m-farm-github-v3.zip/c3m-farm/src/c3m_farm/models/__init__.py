"""C3M-Farm model components."""

from .c3m_farm import C3MFarm

__all__ = ["C3MFarm"]
