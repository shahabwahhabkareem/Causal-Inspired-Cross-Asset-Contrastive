"""Complete C3M-Farm reference model."""

from __future__ import annotations

import itertools

import torch
from torch import nn

from .components import (
    AttentionFusion,
    Disentangler,
    GraphEncoder,
    build_context_knn_adjacency,
)
from .encoders import AcousticEncoder, ContextEncoder, ImageEncoder, SensorEncoder, SpectralEncoder, TextEncoder


class C3MFarm(nn.Module):
    """Causal-inspired multimodal maintenance architecture without causal-identification claims."""

    def __init__(self, config) -> None:
        super().__init__()
        model = config.model
        graph = config.proxy_views["graph"]
        hidden_dim = int(model["encoder_hidden_dim"])
        latent_dim = int(model["latent_dim"])
        unified_dim = int(model["unified_dim"])
        dropout = float(model["dropout"])
        self.latent_dim = latent_dim
        self.unified_dim = unified_dim
        self.graph_config = graph

        self.encoders = nn.ModuleDict(
            {
                "sensor": SensorEncoder(int(model.get("sensor_channels", 21)), hidden_dim, dropout),
                "spectral": SpectralEncoder(int(model.get("spectral_channels", 21)), hidden_dim, dropout),
                "context": ContextEncoder(int(model.get("context_dim", 3)), hidden_dim, dropout),
                "image": ImageEncoder(
                    hidden_dim,
                    dropout,
                    channels=int(model.get("image_channels", 3)),
                ),
                "acoustic": AcousticEncoder(
                    int(model.get("acoustic_channels", 1)),
                    hidden_dim,
                    dropout,
                ),
                "text": TextEncoder(
                    vocab_size=int(model["text_vocab_size"]),
                    embedding_dim=int(model["text_embedding_dim"]),
                    hidden_dim=hidden_dim,
                    dropout=dropout,
                ),
            }
        )
        self.disentanglers = nn.ModuleDict(
            {
                name: Disentangler(hidden_dim, latent_dim, dropout)
                for name in self.encoders
            }
        )

        node_dim = latent_dim * 3
        self.graph_encoder = GraphEncoder(
            input_dim=node_dim,
            hidden_dim=int(model["graph_hidden_dim"]),
            layers=int(model["graph_layers"]),
            dropout=dropout,
        )
        self.health_projection = nn.Linear(latent_dim, unified_dim)
        self.environment_projection = nn.Linear(latent_dim, unified_dim)
        self.residual_projection = nn.Linear(latent_dim, unified_dim)
        self.graph_projection = nn.Linear(int(model["graph_hidden_dim"]), unified_dim)
        self.fusion = AttentionFusion(unified_dim)

        self.classification_head = nn.Linear(unified_dim, int(model["num_classes"]))
        self.rul_head = nn.Linear(unified_dim, 1)
        self.risk_head = nn.Linear(unified_dim, 1)
        self.urgency_head = nn.Linear(unified_dim, 1)
        self.trajectory_predictor = nn.Sequential(
            nn.Linear(latent_dim * 2, unified_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(unified_dim, latent_dim),
        )

    def _encode(
        self,
        modalities: dict[str, torch.Tensor],
    ) -> tuple[dict[str, torch.Tensor], dict[str, dict[str, torch.Tensor]]]:
        hidden: dict[str, torch.Tensor] = {}
        latent: dict[str, dict[str, torch.Tensor]] = {}
        for name, values in modalities.items():
            if name not in self.encoders:
                continue
            hidden[name] = self.encoders[name](values)
            latent[name] = self.disentanglers[name](hidden[name])
        if not latent:
            raise ValueError("No supported modalities were supplied.")
        return hidden, latent

    @staticmethod
    def _mean_latent(
        latent: dict[str, dict[str, torch.Tensor]],
        key: str,
    ) -> torch.Tensor:
        return torch.stack([item[key] for item in latent.values()], dim=0).mean(dim=0)

    def encode_health(self, modalities: dict[str, torch.Tensor]) -> torch.Tensor:
        _, latent = self._encode(modalities)
        return self._mean_latent(latent, "health")

    def forward(
        self,
        modalities: dict[str, torch.Tensor],
        engine_ids: torch.Tensor,
        adjacency: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor | dict]:
        hidden, latent = self._encode(modalities)
        health = self._mean_latent(latent, "health")
        environment = self._mean_latent(latent, "environment")
        residual = self._mean_latent(latent, "residual")
        node_features = torch.cat([health, environment, residual], dim=-1)

        if adjacency is None:
            if "context" not in modalities:
                adjacency = torch.zeros(
                    (health.shape[0], health.shape[0]),
                    dtype=health.dtype,
                    device=health.device,
                )
            else:
                adjacency = build_context_knn_adjacency(
                    context=modalities["context"],
                    engine_ids=engine_ids,
                    k=int(self.graph_config["k"]),
                    temperature=float(self.graph_config["temperature"]),
                    exclude_same_asset=bool(self.graph_config["exclude_same_asset"]),
                )

        graph_embedding = self.graph_encoder(node_features, adjacency)
        candidates = [
            self.health_projection(latent[name]["health"])
            for name in sorted(latent)
        ]
        candidates.extend(
            [
                self.environment_projection(environment),
                self.residual_projection(residual),
                self.graph_projection(graph_embedding),
            ]
        )
        fused, attention = self.fusion(candidates)
        class_logits = self.classification_head(fused)
        rul = self.rul_head(fused).squeeze(-1)
        risk_logits = self.risk_head(fused).squeeze(-1)
        urgency = torch.sigmoid(self.urgency_head(fused).squeeze(-1))
        predicted_future_health = self.trajectory_predictor(
            torch.cat([health, environment], dim=-1)
        )

        return {
            "hidden": hidden,
            "latent": latent,
            "health": health,
            "environment": environment,
            "residual": residual,
            "adjacency": adjacency,
            "graph_embedding": graph_embedding,
            "fused": fused,
            "attention": attention,
            "class_logits": class_logits,
            "rul": rul,
            "risk_logits": risk_logits,
            "urgency": urgency,
            "predicted_future_health": predicted_future_health,
            "modality_pairs": list(itertools.combinations(sorted(latent), 2)),
        }
