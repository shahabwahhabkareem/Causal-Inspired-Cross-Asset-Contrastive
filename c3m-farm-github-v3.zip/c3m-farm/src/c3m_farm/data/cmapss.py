"""Leakage-safe C-MAPSS loading, grouped splitting, scaling, and windowing."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

SETTING_COLUMNS = [f"setting_{index}" for index in range(1, 4)]
SENSOR_COLUMNS = [f"sensor_{index}" for index in range(1, 22)]
CMAPSS_COLUMNS = ["engine_id", "cycle", *SETTING_COLUMNS, *SENSOR_COLUMNS]


@dataclass(frozen=True)
class EngineSplit:
    train: tuple[int, ...]
    val: tuple[int, ...]
    test: tuple[int, ...]



def validate_engine_split(split: EngineSplit, available_engine_ids: Iterable[int]) -> None:
    """Validate disjointness, non-emptiness, and membership for an explicit engine split."""
    available = {int(value) for value in available_engine_ids}
    train = set(split.train)
    val = set(split.val)
    test = set(split.test)
    if not train or not val or not test:
        raise ValueError("Explicit train/validation/test engine partitions must be non-empty.")
    if not train.isdisjoint(val) or not train.isdisjoint(test) or not val.isdisjoint(test):
        raise ValueError("Explicit engine partitions must be mutually disjoint.")
    requested = train | val | test
    unknown = requested - available
    if unknown:
        raise ValueError(f"Explicit split contains unknown engine IDs: {sorted(unknown)}")


def load_engine_split_manifest(path: str | Path) -> EngineSplit:
    """Load train/validation/test engine IDs from a JSON split manifest."""
    import json

    manifest_path = Path(path)
    with manifest_path.open("r", encoding="utf-8") as stream:
        payload = json.load(stream)
    return EngineSplit(
        train=tuple(int(value) for value in payload["train_engines"]),
        val=tuple(int(value) for value in payload["val_engines"]),
        test=tuple(int(value) for value in payload["test_engines"]),
    )


class TrainOnlyMinMaxScaler:
    """Min-max scaling with immutable statistics fitted on training engines only."""

    def __init__(self) -> None:
        self.minimum: np.ndarray | None = None
        self.maximum: np.ndarray | None = None

    def fit(self, values: np.ndarray) -> "TrainOnlyMinMaxScaler":
        self.minimum = np.nanmin(values, axis=0)
        self.maximum = np.nanmax(values, axis=0)
        return self

    def transform(self, values: np.ndarray) -> np.ndarray:
        if self.minimum is None or self.maximum is None:
            raise RuntimeError("Scaler must be fit before transform.")
        denominator = np.maximum(self.maximum - self.minimum, 1e-12)
        return (values - self.minimum) / denominator

    def state_dict(self) -> dict[str, list[float]]:
        if self.minimum is None or self.maximum is None:
            raise RuntimeError("Scaler is not fit.")
        return {
            "minimum": self.minimum.tolist(),
            "maximum": self.maximum.tolist(),
        }


def load_train_subset(data_root: str | Path, subset: str) -> pd.DataFrame:
    path = Path(data_root) / f"train_{subset}.txt"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {path}. Place the original NASA C-MAPSS files under the data root."
        )
    frame = pd.read_csv(path, sep=r"\s+", header=None, engine="python")
    if frame.shape[1] < len(CMAPSS_COLUMNS):
        raise ValueError(f"{path} has {frame.shape[1]} columns; expected at least 26.")
    frame = frame.iloc[:, : len(CMAPSS_COLUMNS)]
    frame.columns = CMAPSS_COLUMNS
    frame["engine_id"] = frame["engine_id"].astype(int)
    frame["cycle"] = frame["cycle"].astype(int)
    return frame


def split_engine_ids(
    engine_ids: Iterable[int],
    train_fraction: float,
    val_fraction: float,
    seed: int,
) -> EngineSplit:
    unique_ids = np.array(sorted(set(int(value) for value in engine_ids)), dtype=int)
    if len(unique_ids) < 3:
        raise ValueError("At least three engines are required for train/val/test splitting.")
    rng = np.random.default_rng(seed)
    shuffled = unique_ids.copy()
    rng.shuffle(shuffled)
    n_total = len(shuffled)
    n_train = min(max(1, int(round(n_total * train_fraction))), n_total - 2)
    n_val = min(max(1, int(round(n_total * val_fraction))), n_total - n_train - 1)
    n_test_start = n_train + n_val
    return EngineSplit(
        train=tuple(sorted(shuffled[:n_train].tolist())),
        val=tuple(sorted(shuffled[n_train:n_test_start].tolist())),
        test=tuple(sorted(shuffled[n_test_start:].tolist())),
    )


def add_rul(frame: pd.DataFrame, cap: int) -> pd.DataFrame:
    result = frame.copy()
    max_cycles = result.groupby("engine_id")["cycle"].transform("max")
    actual_rul = max_cycles - result["cycle"]
    result["rul"] = np.minimum(actual_rul.to_numpy(), cap).astype(np.float32)
    return result


def add_fault_class(frame: pd.DataFrame, thresholds: list[int]) -> pd.DataFrame:
    if len(thresholds) != 2 or thresholds[0] >= thresholds[1]:
        raise ValueError("class_thresholds must contain two increasing RUL thresholds.")
    low, high = thresholds
    result = frame.copy()
    rul = result["rul"].to_numpy()
    result["fault_class"] = np.where(rul <= low, 2, np.where(rul <= high, 1, 0)).astype(int)
    return result


def _stft(sensor_window: torch.Tensor, win_length: int, hop_length: int, n_fft: int) -> torch.Tensor:
    signals = sensor_window.transpose(0, 1)
    if signals.shape[-1] < win_length:
        raise ValueError("Window length must be at least the STFT win_length.")
    frames = signals.unfold(-1, win_length, hop_length)
    window = torch.hann_window(win_length, dtype=signals.dtype, device=signals.device)
    spectrum = torch.fft.rfft(frames * window, n=n_fft, dim=-1).abs()
    return spectrum.permute(0, 2, 1).contiguous()


class LeakageSafeTextView:
    """Deterministic proxy text tokens derived only from the current normalized sensor window."""

    PAD = 0
    RISING = 1
    FALLING = 2
    STABLE = 3
    VOLATILE = 4
    SENSOR_OFFSET = 8

    def __init__(
        self,
        max_tokens: int,
        top_k_sensors: int,
        trend_threshold: float,
        volatility_threshold: float,
    ) -> None:
        self.max_tokens = max_tokens
        self.top_k_sensors = top_k_sensors
        self.trend_threshold = trend_threshold
        self.volatility_threshold = volatility_threshold

    def encode(self, sensor_window: torch.Tensor) -> torch.Tensor:
        quarter = max(1, sensor_window.shape[0] // 4)
        first = sensor_window[:quarter].mean(dim=0)
        last = sensor_window[-quarter:].mean(dim=0)
        trend = last - first
        volatility = sensor_window.std(dim=0)
        top_indices = torch.topk(
            trend.abs(),
            k=min(self.top_k_sensors, sensor_window.shape[1]),
        ).indices.tolist()

        tokens: list[int] = []
        for sensor_index in top_indices:
            tokens.append(self.SENSOR_OFFSET + sensor_index)
            if volatility[sensor_index].item() >= self.volatility_threshold:
                state = self.VOLATILE
            elif trend[sensor_index].item() >= self.trend_threshold:
                state = self.RISING
            elif trend[sensor_index].item() <= -self.trend_threshold:
                state = self.FALLING
            else:
                state = self.STABLE
            tokens.append(state)

        tokens = tokens[: self.max_tokens]
        tokens.extend([self.PAD] * (self.max_tokens - len(tokens)))
        return torch.tensor(tokens, dtype=torch.long)


@dataclass(frozen=True)
class WindowRecord:
    engine_id: int
    end_cycle: int
    sensor: np.ndarray
    context: np.ndarray
    rul: float
    fault_class: int
    future_sensor: np.ndarray
    future_context: np.ndarray
    future_valid: bool


class CMapssWindowDataset(Dataset):
    """Fixed windows produced only after engine-group partitioning."""

    def __init__(
        self,
        frame: pd.DataFrame,
        engine_ids: Iterable[int],
        sensor_scaler: TrainOnlyMinMaxScaler,
        context_scaler: TrainOnlyMinMaxScaler,
        window_length: int,
        stride: int,
        trajectory_horizon: int,
        stft_config: dict,
        text_config: dict,
    ) -> None:
        self.window_length = window_length
        self.stride = stride
        self.trajectory_horizon = trajectory_horizon
        self.stft_config = stft_config
        self.text_config = text_config
        self.text_view = LeakageSafeTextView(
            max_tokens=int(text_config["max_tokens"]),
            top_k_sensors=int(text_config["top_k_sensors"]),
            trend_threshold=float(text_config["trend_threshold"]),
            volatility_threshold=float(text_config["volatility_threshold"]),
        )
        self.records = self._build_records(
            frame=frame,
            engine_ids=engine_ids,
            sensor_scaler=sensor_scaler,
            context_scaler=context_scaler,
        )

    def _build_records(
        self,
        frame: pd.DataFrame,
        engine_ids: Iterable[int],
        sensor_scaler: TrainOnlyMinMaxScaler,
        context_scaler: TrainOnlyMinMaxScaler,
    ) -> list[WindowRecord]:
        records: list[WindowRecord] = []
        selected = frame[frame["engine_id"].isin(list(engine_ids))]
        for engine_id, engine_frame in selected.groupby("engine_id"):
            engine_frame = engine_frame.sort_values("cycle").reset_index(drop=True)
            sensors = sensor_scaler.transform(engine_frame[SENSOR_COLUMNS].to_numpy(np.float32))
            contexts = context_scaler.transform(engine_frame[SETTING_COLUMNS].to_numpy(np.float32))
            for start in range(0, len(engine_frame) - self.window_length + 1, self.stride):
                end = start + self.window_length
                future_start = start + self.trajectory_horizon
                future_end = future_start + self.window_length
                future_valid = future_end <= len(engine_frame)
                if future_valid:
                    future_sensor = sensors[future_start:future_end]
                    future_context = contexts[future_start:future_end].mean(axis=0)
                else:
                    future_sensor = sensors[start:end]
                    future_context = contexts[start:end].mean(axis=0)

                row = engine_frame.iloc[end - 1]
                records.append(
                    WindowRecord(
                        engine_id=int(engine_id),
                        end_cycle=int(row["cycle"]),
                        sensor=sensors[start:end],
                        context=contexts[start:end].mean(axis=0),
                        rul=float(row["rul"]),
                        fault_class=int(row["fault_class"]),
                        future_sensor=future_sensor,
                        future_context=future_context,
                        future_valid=future_valid,
                    )
                )
        if not records:
            raise ValueError("No windows were generated. Check split and window length.")
        return records

    def __len__(self) -> int:
        return len(self.records)

    def _modalities(self, sensor: torch.Tensor, context: torch.Tensor) -> dict[str, torch.Tensor]:
        modalities: dict[str, torch.Tensor] = {
            "sensor": sensor,
            "context": context,
        }
        if self.stft_config.get("enabled", True):
            modalities["spectral"] = _stft(
                sensor,
                win_length=int(self.stft_config["win_length"]),
                hop_length=int(self.stft_config["hop_length"]),
                n_fft=int(self.stft_config["n_fft"]),
            )
        if self.text_config.get("enabled", True):
            modalities["text"] = self.text_view.encode(sensor)
        return modalities

    def __getitem__(self, index: int) -> dict:
        record = self.records[index]
        sensor = torch.tensor(record.sensor, dtype=torch.float32)
        context = torch.tensor(record.context, dtype=torch.float32)
        future_sensor = torch.tensor(record.future_sensor, dtype=torch.float32)
        future_context = torch.tensor(record.future_context, dtype=torch.float32)
        return {
            "modalities": self._modalities(sensor, context),
            "future_modalities": self._modalities(future_sensor, future_context),
            "engine_id": torch.tensor(record.engine_id, dtype=torch.long),
            "end_cycle": torch.tensor(record.end_cycle, dtype=torch.long),
            "rul": torch.tensor(record.rul, dtype=torch.float32),
            "fault_class": torch.tensor(record.fault_class, dtype=torch.long),
            "future_valid": torch.tensor(record.future_valid, dtype=torch.bool),
        }


class CMapssDataModule:
    """Build grouped train/validation/test loaders using one frozen train-only scaler."""

    def __init__(
        self,
        data_root: str | Path,
        subset: str,
        seed: int,
        config,
        split_override: EngineSplit | None = None,
    ) -> None:
        self.data_root = Path(data_root)
        self.subset = subset
        self.seed = seed
        self.config = config
        self.split_override = split_override
        self.frame: pd.DataFrame | None = None
        self.split: EngineSplit | None = None
        self.sensor_scaler = TrainOnlyMinMaxScaler()
        self.context_scaler = TrainOnlyMinMaxScaler()

    def setup(self) -> None:
        data_config = self.config.data
        frame = load_train_subset(self.data_root, self.subset)
        frame = add_rul(frame, int(data_config["rul_cap"]))
        frame = add_fault_class(frame, list(data_config["class_thresholds"]))
        if self.split_override is None:
            split = split_engine_ids(
                frame["engine_id"].unique(),
                train_fraction=float(data_config["train_fraction"]),
                val_fraction=float(data_config["val_fraction"]),
                seed=self.seed,
            )
        else:
            split = self.split_override
            validate_engine_split(split, frame["engine_id"].unique())
        training_rows = frame[frame["engine_id"].isin(split.train)]
        self.sensor_scaler.fit(training_rows[SENSOR_COLUMNS].to_numpy(np.float32))
        self.context_scaler.fit(training_rows[SETTING_COLUMNS].to_numpy(np.float32))
        self.frame = frame
        self.split = split

    def _dataset(self, engine_ids: Iterable[int]) -> CMapssWindowDataset:
        if self.frame is None:
            raise RuntimeError("Call setup() before requesting datasets.")
        return CMapssWindowDataset(
            frame=self.frame,
            engine_ids=engine_ids,
            sensor_scaler=self.sensor_scaler,
            context_scaler=self.context_scaler,
            window_length=int(self.config.data["window_length"]),
            stride=int(self.config.data["stride"]),
            trajectory_horizon=int(self.config.data["trajectory_horizon"]),
            stft_config=self.config.proxy_views["stft"],
            text_config=self.config.proxy_views["text"],
        )

    def loaders(
        self,
        batch_size: int | None = None,
        num_workers: int | None = None,
    ) -> tuple[DataLoader, DataLoader, DataLoader]:
        if self.split is None:
            self.setup()
        assert self.split is not None
        batch_size = int(batch_size or self.config.training["batch_size"])
        workers = int(
            self.config.training.get("num_workers", 0)
            if num_workers is None
            else num_workers
        )
        train = DataLoader(
            self._dataset(self.split.train),
            batch_size=batch_size,
            shuffle=True,
            num_workers=workers,
        )
        val = DataLoader(
            self._dataset(self.split.val),
            batch_size=batch_size,
            shuffle=False,
            num_workers=workers,
        )
        test = DataLoader(
            self._dataset(self.split.test),
            batch_size=batch_size,
            shuffle=False,
            num_workers=workers,
        )
        return train, val, test

    def split_manifest(self) -> dict:
        if self.split is None:
            raise RuntimeError("Call setup() before requesting split metadata.")
        return {
            "seed": self.seed,
            "subset": self.subset,
            "train_engines": list(self.split.train),
            "val_engines": list(self.split.val),
            "test_engines": list(self.split.test),
            "sensor_scaler": self.sensor_scaler.state_dict(),
            "context_scaler": self.context_scaler.state_dict(),
        }
