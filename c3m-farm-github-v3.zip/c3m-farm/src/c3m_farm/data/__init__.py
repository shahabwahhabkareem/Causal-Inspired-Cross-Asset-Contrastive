"""C-MAPSS data loading and reference proxy-view generation."""

from .cmapss import CMapssDataModule, CMapssWindowDataset

__all__ = ["CMapssDataModule", "CMapssWindowDataset"]
