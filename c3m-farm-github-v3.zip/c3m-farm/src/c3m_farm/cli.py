"""Command-line entry points."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from .config import load_config
from .data.cmapss import CMapssDataModule, load_engine_split_manifest
from .models.c3m_farm import C3MFarm
from .training import Trainer, set_seed


def train_main() -> None:
    parser = argparse.ArgumentParser(description="Train one C3M-Farm C-MAPSS run.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--subset", choices=["FD001", "FD002", "FD003", "FD004"], required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--output-root", default="runs")
    parser.add_argument("--split-manifest", default=None)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    config = load_config(args.config, require_runnable=True)
    allowed_seeds = set(int(value) for value in config.training["random_seeds"])
    if args.seed not in allowed_seeds:
        raise ValueError(f"Seed {args.seed} is not listed in config random_seeds={sorted(allowed_seeds)}.")

    set_seed(args.seed)
    device = torch.device(
        args.device
        if args.device
        else ("cuda" if torch.cuda.is_available() else "cpu")
    )

    split_override = (
        load_engine_split_manifest(args.split_manifest)
        if args.split_manifest
        else None
    )
    data = CMapssDataModule(
        args.data_root,
        args.subset,
        args.seed,
        config,
        split_override=split_override,
    )
    data.setup()
    train_loader, val_loader, test_loader = data.loaders()

    output_dir = Path(args.output_root) / args.subset / f"seed_{args.seed}"
    model = C3MFarm(config)
    trainer = Trainer(model, config, device, output_dir)
    trainer.fit(train_loader, val_loader)
    _, metrics = trainer.evaluate(test_loader)
    trainer.write_run_manifest(args.subset, args.seed, data.split_manifest())

    print(json.dumps(metrics, indent=2))
    print(f"Artifacts: {output_dir}")
