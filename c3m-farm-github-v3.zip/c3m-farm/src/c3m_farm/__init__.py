"""C3M-Farm auditable reference implementation."""

from .models.c3m_farm import C3MFarm

__all__ = ["C3MFarm"]
__version__ = "0.3.0"
