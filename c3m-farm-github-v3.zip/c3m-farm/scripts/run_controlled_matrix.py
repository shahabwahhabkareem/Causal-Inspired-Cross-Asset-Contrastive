#!/usr/bin/env python
"""Run C3M-Farm and controlled baselines across FD001-FD004 and all manuscript seeds."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SUBSETS = ("FD001", "FD002", "FD003", "FD004")
SEEDS = (42, 123, 456)
BASELINES = {
    "decision_transformer": "configs/baselines/decision_transformer_controlled.yaml",
    "macptd": "configs/baselines/macptd_controlled.yaml",
    "transformer_gru": "configs/baselines/transformer_gru_controlled.yaml",
}


def run(command: list[str], dry_run: bool) -> None:
    print("+", " ".join(command), flush=True)
    if not dry_run:
        subprocess.run(command, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", default="data/raw/CMaps")
    parser.add_argument("--output-root", default="runs/controlled")
    parser.add_argument(
        "--models",
        nargs="+",
        default=["c3m", *BASELINES],
        choices=["c3m", *BASELINES],
    )
    parser.add_argument("--subsets", nargs="+", default=list(SUBSETS), choices=SUBSETS)
    parser.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    parser.add_argument("--device", default=None)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    python = sys.executable
    for subset in args.subsets:
        for seed in args.seeds:
            if "c3m" in args.models:
                command = [
                    python,
                    "-m",
                    "c3m_farm.cli",
                    "--config",
                    "configs/reference_cmapss.yaml",
                    "--subset",
                    subset,
                    "--seed",
                    str(seed),
                    "--data-root",
                    args.data_root,
                    "--output-root",
                    str(Path(args.output_root) / "c3m"),
                ]
                if args.device:
                    command.extend(["--device", args.device])
                run(command, args.dry_run)

            for model_name, config_path in BASELINES.items():
                if model_name not in args.models:
                    continue
                command = [
                    python,
                    "-m",
                    "c3m_farm.baseline_cli",
                    "--baseline-config",
                    config_path,
                    "--shared-config",
                    "configs/reference_cmapss.yaml",
                    "--subset",
                    subset,
                    "--seed",
                    str(seed),
                    "--data-root",
                    args.data_root,
                    "--output-root",
                    str(Path(args.output_root) / "baselines"),
                ]
                if args.device:
                    command.extend(["--device", args.device])
                run(command, args.dry_run)


if __name__ == "__main__":
    main()
