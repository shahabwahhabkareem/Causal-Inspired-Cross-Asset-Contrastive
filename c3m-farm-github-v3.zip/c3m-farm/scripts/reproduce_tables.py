#!/usr/bin/env python
"""Regenerate machine-readable and Markdown tables from manuscript-supported summary records."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts/generated"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    preserved = load_json(ROOT / "artifacts/preserved/preliminary_results.json")
    controlled = load_json(ROOT / "artifacts/controlled/controlled_summary.json")

    tables = {
        "table3_training_sizes": pd.DataFrame.from_dict(
            preserved["training_sizes"], orient="index"
        ).rename_axis("training_samples"),
        "table4_baselines": pd.DataFrame.from_dict(
            preserved["baseline_table"], orient="index"
        ).rename_axis("model"),
        "table5_cross_validation": pd.DataFrame(preserved["cross_validation"]),
        "table6_ablation": pd.DataFrame.from_dict(
            preserved["ablation_table"], orient="index"
        ).rename_axis("variant"),
        "table8_controlled": pd.DataFrame.from_dict(
            controlled["table8"], orient="index"
        ).rename_axis("method"),
        "table9_pvalues": pd.DataFrame.from_dict(
            controlled["table9"], orient="index"
        ).rename_axis("comparison"),
    }

    for name, frame in tables.items():
        frame.to_csv(OUT / f"{name}.csv")
        (OUT / f"{name}.md").write_text(frame.to_markdown(), encoding="utf-8")

    print(f"Generated {len(tables)} tables in {OUT}")


if __name__ == "__main__":
    main()
