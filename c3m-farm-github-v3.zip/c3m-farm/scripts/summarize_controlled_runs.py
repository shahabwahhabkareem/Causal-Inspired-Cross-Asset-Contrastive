#!/usr/bin/env python
"""Summarize controlled per-seed RMSE outputs without replacing manuscript canonical records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def metric_from_file(path: Path, metric_scope: str) -> float:
    with path.open("r", encoding="utf-8") as stream:
        data = json.load(stream)
    if metric_scope in data:
        return float(data[metric_scope]["rmse"])
    return float(data["rmse"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs-root", default="runs/controlled")
    parser.add_argument(
        "--metric-scope",
        default="window",
        choices=["window", "final_window_per_engine"],
    )
    parser.add_argument("--output", default="artifacts/generated/controlled_rerun_summary.csv")
    args = parser.parse_args()

    runs_root = Path(args.runs_root)
    rows = []
    for metrics_path in runs_root.rglob("metrics.json"):
        parts = metrics_path.parts
        subset = next((part for part in parts if part.startswith("FD00")), None)
        seed_part = next((part for part in parts if part.startswith("seed_")), None)
        if subset is None or seed_part is None:
            continue
        seed = int(seed_part.removeprefix("seed_"))
        relative = metrics_path.relative_to(runs_root).parts
        model = "/".join(relative[:-3])
        rows.append(
            {
                "model": model,
                "subset": subset,
                "seed": seed,
                "rmse": metric_from_file(metrics_path, args.metric_scope),
            }
        )

    if not rows:
        raise SystemExit(f"No metrics.json files found under {runs_root}")

    raw = pd.DataFrame(rows)
    summary = (
        raw.groupby(["model", "subset"])["rmse"]
        .agg(["mean", "std", "count"])
        .reset_index()
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output, index=False)
    raw.to_csv(output.with_name(output.stem + "_per_seed.csv"), index=False)
    print(summary.to_string(index=False))
    print(f"Wrote {output}")


if __name__ == "__main__":
    main()
