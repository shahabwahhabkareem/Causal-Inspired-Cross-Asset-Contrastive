#!/usr/bin/env python
"""Import a locally supplied C-MAPSS ZIP into the repository's expected layout."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

EXPECTED = [
    *(f"train_FD00{index}.txt" for index in range(1, 5)),
    *(f"test_FD00{index}.txt" for index in range(1, 5)),
    *(f"RUL_FD00{index}.txt" for index in range(1, 5)),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def recursively_extract(archive_path: Path, destination: Path) -> None:
    queue = [archive_path]
    visited: set[Path] = set()
    while queue:
        current = queue.pop()
        current = current.resolve()
        if current in visited:
            continue
        visited.add(current)
        with zipfile.ZipFile(current) as archive:
            archive.extractall(destination)
        for nested in destination.rglob("*.zip"):
            resolved = nested.resolve()
            if resolved not in visited:
                queue.append(nested)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", required=True, help="Path to CMAPSSData.zip or NASA archive.")
    parser.add_argument("--output", default="data/raw/CMaps")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    archive_path = Path(args.archive).expanduser().resolve()
    if not archive_path.exists():
        raise FileNotFoundError(f"C-MAPSS archive not found: {archive_path}")
    if not zipfile.is_zipfile(archive_path):
        raise ValueError(f"Not a ZIP archive: {archive_path}")

    output = Path(args.output)
    if output.exists() and not args.force:
        existing = [name for name in EXPECTED if (output / name).exists()]
        if existing:
            raise FileExistsError(
                f"{output} already contains C-MAPSS files. Use --force to replace them."
            )

    with tempfile.TemporaryDirectory(prefix="cmapss-import-") as temp_dir:
        extracted = Path(temp_dir) / "extracted"
        extracted.mkdir(parents=True)
        recursively_extract(archive_path, extracted)

        located: dict[str, Path] = {}
        for filename in EXPECTED:
            matches = list(extracted.rglob(filename))
            if not matches:
                raise FileNotFoundError(f"Archive does not contain required file: {filename}")
            located[filename] = matches[0]

        output.mkdir(parents=True, exist_ok=True)
        for filename, source in located.items():
            shutil.copy2(source, output / filename)

    manifest = {
        "source_type": "user_supplied_archive",
        "source_archive_name": archive_path.name,
        "source_archive_sha256": sha256(archive_path),
        "files": {
            filename: sha256(output / filename)
            for filename in EXPECTED
        },
    }
    (output / "SOURCE.json").write_text(
        json.dumps(manifest, indent=2),
        encoding="utf-8",
    )
    print(f"Imported all 12 standard C-MAPSS files into {output}")
    print(f"Source manifest: {output / 'SOURCE.json'}")


if __name__ == "__main__":
    main()
