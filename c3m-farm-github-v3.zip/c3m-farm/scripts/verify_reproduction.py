#!/usr/bin/env python
"""Verify all summary values that can be audited from the supplied manuscript records."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from c3m_farm.audit import verify_controlled_summary, verify_preserved_results


def main() -> None:
    errors = [*verify_preserved_results(ROOT), *verify_controlled_summary(ROOT)]
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        raise SystemExit(1)
    print("Summary audit passed.")
    print(
        "Raw paired prediction audit: NOT RUN. "
        "Underlying manuscript prediction files were not supplied and are not fabricated."
    )


if __name__ == "__main__":
    main()
