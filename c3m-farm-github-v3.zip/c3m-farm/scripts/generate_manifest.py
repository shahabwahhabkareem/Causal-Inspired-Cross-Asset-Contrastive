#!/usr/bin/env python
"""Generate or verify a SHA-256 manifest for repository files."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.sha256"
EXCLUDED_PARTS = {".git", ".venv", "__pycache__", ".pytest_cache", ".ruff_cache", "runs"}


def eligible_files() -> list[Path]:
    paths = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == MANIFEST:
            continue
        if any(part in EXCLUDED_PARTS for part in path.parts):
            continue
        paths.append(path)
    return sorted(paths)


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def build_lines() -> list[str]:
    return [f"{digest(path)}  {path.relative_to(ROOT).as_posix()}" for path in eligible_files()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    current = "\n".join(build_lines()) + "\n"

    if args.check:
        if not MANIFEST.exists():
            raise SystemExit("MANIFEST.sha256 is missing.")
        expected = MANIFEST.read_text(encoding="utf-8")
        if current != expected:
            raise SystemExit("SHA-256 manifest mismatch. Run scripts/generate_manifest.py.")
        print("SHA-256 manifest verified.")
        return

    MANIFEST.write_text(current, encoding="utf-8")
    print(f"Wrote {MANIFEST}")


if __name__ == "__main__":
    main()
