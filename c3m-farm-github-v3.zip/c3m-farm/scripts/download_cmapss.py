#!/usr/bin/env python
"""Download and extract the original NASA C-MAPSS turbofan dataset."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

NASA_URL = (
    "https://phm-datasets.s3.amazonaws.com/NASA/"
    "6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip"
)
ZENODO_FALLBACK = "https://zenodo.org/records/15346912/files/CMAPSSData.zip?download=1"

EXPECTED = [
    *(f"train_FD00{index}.txt" for index in range(1, 5)),
    *(f"test_FD00{index}.txt" for index in range(1, 5)),
    *(f"RUL_FD00{index}.txt" for index in range(1, 5)),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, destination: Path) -> None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "c3m-farm-reproducibility/0.2"},
    )
    with urllib.request.urlopen(request, timeout=120) as response:
        with destination.open("wb") as stream:
            shutil.copyfileobj(response, stream)


def extract_recursive(zip_path: Path, destination: Path) -> None:
    queue = [zip_path]
    visited: set[Path] = set()
    while queue:
        current = queue.pop()
        if current in visited:
            continue
        visited.add(current)
        with zipfile.ZipFile(current) as archive:
            archive.extractall(destination)
        queue.extend(
            path
            for path in destination.rglob("*.zip")
            if path not in visited
        )


def collect_expected(search_root: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for filename in EXPECTED:
        matches = list(search_root.rglob(filename))
        if not matches:
            raise FileNotFoundError(f"Downloaded archive does not contain {filename}.")
        shutil.copy2(matches[0], target / filename)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/raw/CMaps")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    target = Path(args.output)
    if target.exists() and not args.force:
        existing = [name for name in EXPECTED if (target / name).exists()]
        if len(existing) == len(EXPECTED):
            print(f"C-MAPSS already present at {target}")
            return

    errors: list[str] = []
    with tempfile.TemporaryDirectory(prefix="cmapss-") as temp_dir:
        temp = Path(temp_dir)
        archive = temp / "cmapss.zip"
        used_url = None
        for url in (NASA_URL, ZENODO_FALLBACK):
            try:
                download(url, archive)
                used_url = url
                break
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                errors.append(f"{url}: {exc}")
        if used_url is None:
            raise SystemExit("Could not download C-MAPSS:\n" + "\n".join(errors))

        archive_hash = sha256(archive)
        extract_root = temp / "extracted"
        extract_root.mkdir()
        extract_recursive(archive, extract_root)
        collect_expected(extract_root, target)

        manifest = {
            "source_url": used_url,
            "download_sha256": archive_hash,
            "files": {
                filename: sha256(target / filename)
                for filename in EXPECTED
            },
        }
        (target / "SOURCE.json").write_text(
            json.dumps(manifest, indent=2),
            encoding="utf-8",
        )

    print(f"Downloaded C-MAPSS to {target}")
    print(f"Source manifest: {target / 'SOURCE.json'}")


if __name__ == "__main__":
    main()
