#!/usr/bin/env python
"""Run engine-grouped five-fold C-MAPSS experiments with identical folds for every model."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from c3m_farm.cross_validation import (
    make_grouped_kfold_splits,
    make_repeated_grouped_holdout_splits,
    save_folds,
    save_single_split,
)
from c3m_farm.data.cmapss import load_train_subset

SUBSETS = ("FD001", "FD002", "FD003", "FD004")
BASELINE_CONFIGS = {
    "decision_transformer": "configs/baselines/decision_transformer_controlled.yaml",
    "macptd": "configs/baselines/macptd_controlled.yaml",
    "transformer_gru": "configs/baselines/transformer_gru_controlled.yaml",
}


def run(command: list[str]) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, check=True)


def append_index(index_path: Path, record: dict) -> None:
    if index_path.exists():
        payload = json.loads(index_path.read_text(encoding="utf-8"))
    else:
        payload = {"runs": []}
    payload["runs"] = [
        item
        for item in payload["runs"]
        if not (
            item["model"] == record["model"]
            and item["subset"] == record["subset"]
            and item["fold"] == record["fold"]
            and item["training_seed"] == record["training_seed"]
        )
    ]
    payload["runs"].append(record)
    index_path.parent.mkdir(parents=True, exist_ok=True)
    index_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def c3m_command(
    python: str,
    data_root: str,
    output_root: Path,
    subset: str,
    seed: int,
    split_manifest: Path,
    device: str | None,
) -> tuple[list[str], Path]:
    command = [
        python,
        "-m",
        "c3m_farm.cli",
        "--config",
        "configs/reference_cmapss.yaml",
        "--subset",
        subset,
        "--seed",
        str(seed),
        "--data-root",
        data_root,
        "--output-root",
        str(output_root),
        "--split-manifest",
        str(split_manifest),
    ]
    if device:
        command.extend(["--device", device])
    return command, output_root / subset / f"seed_{seed}"


def baseline_command(
    python: str,
    model: str,
    data_root: str,
    output_root: Path,
    subset: str,
    seed: int,
    split_manifest: Path,
    device: str | None,
) -> tuple[list[str], Path]:
    config = BASELINE_CONFIGS[model]
    command = [
        python,
        "-m",
        "c3m_farm.baseline_cli",
        "--baseline-config",
        config,
        "--shared-config",
        "configs/reference_cmapss.yaml",
        "--subset",
        subset,
        "--seed",
        str(seed),
        "--data-root",
        data_root,
        "--output-root",
        str(output_root),
        "--split-manifest",
        str(split_manifest),
    ]
    if device:
        command.extend(["--device", device])
    return (
        command,
        output_root
        / model
        / "manuscript_controlled"
        / subset
        / f"seed_{seed}",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", default="data/raw/CMaps")
    parser.add_argument("--output-root", default="runs/grouped_cv")
    parser.add_argument(
        "--protocol",
        choices=["grouped-kfold", "repeated-70-15-15"],
        default="grouped-kfold",
    )
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--fold-seed", type=int, default=42)
    parser.add_argument("--training-seeds", nargs="+", type=int, default=[42, 123, 456])
    parser.add_argument("--subsets", nargs="+", choices=SUBSETS, default=list(SUBSETS))
    parser.add_argument(
        "--models",
        nargs="+",
        choices=["c3m_farm", *BASELINE_CONFIGS],
        default=["c3m_farm", *BASELINE_CONFIGS],
    )
    parser.add_argument("--device", default=None)
    parser.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--splits-only", action="store_true")
    args = parser.parse_args()

    if args.folds != 5:
        print(
            "WARNING: the manuscript-facing paired protocol specifies n=5 folds; "
            f"this run requested {args.folds}."
        )

    root = Path(args.output_root)
    index_path = root / "cv_index.json"
    python = sys.executable

    for subset in args.subsets:
        frame = load_train_subset(args.data_root, subset)
        engine_ids = frame["engine_id"].unique()

        if args.protocol == "grouped-kfold":
            folds = make_grouped_kfold_splits(
                engine_ids,
                n_splits=args.folds,
                fold_seed=args.fold_seed,
                validation_fraction_of_total=0.15,
            )
        else:
            folds = make_repeated_grouped_holdout_splits(
                engine_ids,
                repeats=args.folds,
                base_seed=args.fold_seed,
                train_fraction=0.70,
                val_fraction=0.15,
            )

        split_dir = root / "split_manifests" / args.protocol / subset
        save_folds(
            folds,
            split_dir / "folds.json",
            protocol=args.protocol,
            subset=subset,
            fold_seed=args.fold_seed,
        )

        for fold in folds:
            split_manifest = split_dir / f"fold_{fold.fold}.json"
            save_single_split(
                fold,
                split_manifest,
                protocol=args.protocol,
                subset=subset,
                fold_seed=args.fold_seed,
            )

            if args.splits_only:
                continue

            fold_root = root / "runs" / args.protocol / subset / f"fold_{fold.fold}"
            for training_seed in args.training_seeds:
                if "c3m_farm" in args.models:
                    output_root = fold_root / "c3m_farm"
                    command, run_dir = c3m_command(
                        python,
                        args.data_root,
                        output_root,
                        subset,
                        training_seed,
                        split_manifest,
                        args.device,
                    )
                    metrics = run_dir / "metrics.json"
                    if not (args.resume and metrics.exists()):
                        run(command)
                    append_index(
                        index_path,
                        {
                            "model": "c3m_farm",
                            "subset": subset,
                            "fold": fold.fold,
                            "training_seed": training_seed,
                            "protocol": args.protocol,
                            "split_manifest": str(split_manifest),
                            "run_dir": str(run_dir),
                        },
                    )

                for model in BASELINE_CONFIGS:
                    if model not in args.models:
                        continue
                    output_root = fold_root / "baselines"
                    command, run_dir = baseline_command(
                        python,
                        model,
                        args.data_root,
                        output_root,
                        subset,
                        training_seed,
                        split_manifest,
                        args.device,
                    )
                    metrics = run_dir / "metrics.json"
                    if not (args.resume and metrics.exists()):
                        run(command)
                    append_index(
                        index_path,
                        {
                            "model": model,
                            "subset": subset,
                            "fold": fold.fold,
                            "training_seed": training_seed,
                            "protocol": args.protocol,
                            "split_manifest": str(split_manifest),
                            "run_dir": str(run_dir),
                        },
                    )

    print(f"Cross-validation index: {index_path}")


if __name__ == "__main__":
    main()
