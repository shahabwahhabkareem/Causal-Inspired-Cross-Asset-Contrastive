#!/usr/bin/env python
"""Generate fold-level and per-engine paired statistics from grouped C-MAPSS runs."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from c3m_farm.cross_validation import (
    load_final_engine_predictions,
    p_value_label,
    paired_t_summary,
)

REFERENCE_MODEL = "c3m_farm"


def rmse(values: pd.DataFrame) -> float:
    errors = values["pred_rul"].to_numpy() - values["y_rul"].to_numpy()
    return float(math.sqrt(np.mean(np.square(errors))))


def load_index(index_path: Path) -> list[dict]:
    payload = json.loads(index_path.read_text(encoding="utf-8"))
    return payload["runs"]


def build_records(index_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    fold_rows: list[dict] = []
    engine_rows: list[dict] = []

    for record in load_index(index_path):
        run_dir = Path(record["run_dir"])
        predictions_path = run_dir / "final_window_predictions.csv"
        if not predictions_path.exists():
            raise FileNotFoundError(
                f"Missing {predictions_path}. Complete the indexed run before statistical analysis."
            )

        final = load_final_engine_predictions(predictions_path)
        fold_rows.append(
            {
                "model": record["model"],
                "subset": record["subset"],
                "fold": int(record["fold"]),
                "training_seed": int(record["training_seed"]),
                "rmse": rmse(final),
                "n_engines": int(final["engine_id"].nunique()),
            }
        )

        for row in final.itertuples(index=False):
            engine_rows.append(
                {
                    "model": record["model"],
                    "subset": record["subset"],
                    "fold": int(record["fold"]),
                    "training_seed": int(record["training_seed"]),
                    "engine_id": int(row.engine_id),
                    "y_rul": float(row.y_rul),
                    "pred_rul": float(row.pred_rul),
                    "absolute_error": abs(float(row.pred_rul) - float(row.y_rul)),
                    "squared_error": (float(row.pred_rul) - float(row.y_rul)) ** 2,
                }
            )

    return pd.DataFrame(fold_rows), pd.DataFrame(engine_rows)


def fold_paired_tests(fold_seed_metrics: pd.DataFrame) -> pd.DataFrame:
    fold_metrics = (
        fold_seed_metrics
        .groupby(["model", "subset", "fold"], as_index=False)
        .agg(
            rmse=("rmse", "mean"),
            seed_sd=("rmse", "std"),
            training_seeds=("training_seed", "nunique"),
        )
    )

    rows: list[dict] = []
    subsets = sorted(fold_metrics["subset"].unique())
    baselines = sorted(set(fold_metrics["model"]) - {REFERENCE_MODEL})
    for subset in subsets:
        reference = (
            fold_metrics[
                (fold_metrics["model"] == REFERENCE_MODEL)
                & (fold_metrics["subset"] == subset)
            ][["fold", "rmse"]]
            .rename(columns={"rmse": "c3m_rmse"})
        )
        for baseline in baselines:
            candidate = (
                fold_metrics[
                    (fold_metrics["model"] == baseline)
                    & (fold_metrics["subset"] == subset)
                ][["fold", "rmse"]]
                .rename(columns={"rmse": "baseline_rmse"})
            )
            paired = reference.merge(candidate, on="fold", how="inner").sort_values("fold")
            if len(paired) < 2:
                continue
            summary = paired_t_summary(
                paired["c3m_rmse"].to_numpy(),
                paired["baseline_rmse"].to_numpy(),
            )
            rows.append(
                {
                    "comparison": f"C3M-Farm vs {baseline}",
                    "baseline": baseline,
                    "subset": subset,
                    "unit": "fold_mean_rmse",
                    **summary,
                    "significance": p_value_label(summary["p_value"]),
                    "c3m_mean_rmse": float(paired["c3m_rmse"].mean()),
                    "baseline_mean_rmse": float(paired["baseline_rmse"].mean()),
                }
            )
    return fold_metrics, pd.DataFrame(rows)


def engine_paired_tests(engine_predictions: pd.DataFrame) -> pd.DataFrame:
    aggregated = (
        engine_predictions
        .groupby(["model", "subset", "fold", "engine_id"], as_index=False)
        .agg(
            y_rul=("y_rul", "first"),
            pred_rul=("pred_rul", "mean"),
            absolute_error=("absolute_error", "mean"),
            squared_error=("squared_error", "mean"),
            training_seeds=("training_seed", "nunique"),
        )
    )

    rows: list[dict] = []
    subsets = sorted(aggregated["subset"].unique())
    baselines = sorted(set(aggregated["model"]) - {REFERENCE_MODEL})
    for subset in subsets:
        reference = aggregated[
            (aggregated["model"] == REFERENCE_MODEL)
            & (aggregated["subset"] == subset)
        ][["fold", "engine_id", "absolute_error", "squared_error"]].rename(
            columns={
                "absolute_error": "c3m_absolute_error",
                "squared_error": "c3m_squared_error",
            }
        )

        for baseline in baselines:
            candidate = aggregated[
                (aggregated["model"] == baseline)
                & (aggregated["subset"] == subset)
            ][["fold", "engine_id", "absolute_error", "squared_error"]].rename(
                columns={
                    "absolute_error": "baseline_absolute_error",
                    "squared_error": "baseline_squared_error",
                }
            )
            paired = reference.merge(candidate, on=["fold", "engine_id"], how="inner")
            if len(paired) < 2:
                continue

            for error_type in ("absolute_error", "squared_error"):
                summary = paired_t_summary(
                    paired[f"c3m_{error_type}"].to_numpy(),
                    paired[f"baseline_{error_type}"].to_numpy(),
                )
                rows.append(
                    {
                        "comparison": f"C3M-Farm vs {baseline}",
                        "baseline": baseline,
                        "subset": subset,
                        "unit": f"per_engine_{error_type}",
                        **summary,
                        "significance": p_value_label(summary["p_value"]),
                    }
                )
    return pd.DataFrame(rows)


def table9(fold_tests: pd.DataFrame) -> pd.DataFrame:
    if fold_tests.empty:
        return pd.DataFrame()
    table = fold_tests.pivot(
        index="comparison",
        columns="subset",
        values="significance",
    )
    order = [column for column in ("FD001", "FD002", "FD003", "FD004") if column in table]
    return table.reindex(columns=order)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", default="runs/grouped_cv/cv_index.json")
    parser.add_argument("--output-dir", default="artifacts/generated/grouped_cv_statistics")
    args = parser.parse_args()

    index_path = Path(args.index)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    fold_seed_metrics, engine_predictions = build_records(index_path)
    fold_metrics, fold_tests = fold_paired_tests(fold_seed_metrics)
    engine_tests = engine_paired_tests(engine_predictions)
    manuscript_table9 = table9(fold_tests)

    fold_seed_metrics.to_csv(output / "fold_seed_metrics.csv", index=False)
    fold_metrics.to_csv(output / "fold_metrics_seed_averaged.csv", index=False)
    fold_tests.to_csv(output / "paired_fold_t_tests.csv", index=False)
    engine_predictions.to_csv(output / "per_engine_predictions.csv", index=False)
    engine_tests.to_csv(output / "paired_engine_error_t_tests.csv", index=False)
    manuscript_table9.to_csv(output / "table9_regenerated.csv")

    metadata = {
        "primary_table9_test": (
            "two-sided paired t-test on five matched fold-level RMSE values; "
            "when multiple training seeds are present, RMSE is averaged within each fold first"
        ),
        "secondary_engine_tests": (
            "two-sided paired t-tests on matched held-out-engine absolute and squared errors"
        ),
        "effect_size": "Cohen's dz on paired differences",
        "confidence_interval": "95% Student-t CI for the paired mean difference",
        "difference_direction": (
            "baseline minus C3M-Farm; positive values favor lower C3M-Farm error"
        ),
    }
    (output / "STATISTICAL_PROTOCOL.json").write_text(
        json.dumps(metadata, indent=2),
        encoding="utf-8",
    )

    print("Primary paired fold tests:")
    if fold_tests.empty:
        print("No complete matched model/fold pairs were found.")
    else:
        print(
            fold_tests[
                [
                    "comparison",
                    "subset",
                    "n",
                    "mean_difference_baseline_minus_c3m",
                    "p_value",
                    "significance",
                    "cohen_dz",
                ]
            ].to_string(index=False)
        )
    print(f"Generated statistical artifacts in {output}")


if __name__ == "__main__":
    main()
